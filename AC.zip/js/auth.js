/* ============================================================
   أمان كاش — 2-auth.js (نسخة نظيفة مضمونة)
   ============================================================ */

/* ---------- selectRole ---------- */
function selectRole(role) {
  try {
    selectedLoginRole = role;

    document.querySelectorAll('.role-card').forEach(function(c) {
      c.classList.toggle('active', c.dataset.role === role);
    });

    var loginBtn = $('loginBtn');
    var regBtn = $('registerBtn');
    var merFields = $('merchantFields');
    var tabReg = $('tabRegister');
    var emailField = $('emailField');
    var loginIdLabel = $('loginIdLabel');
    var loginEmail = $('loginEmail');
    var loginPass = $('loginPass');
    var loginForm = $('loginForm');
    var regForm = $('registerForm');

    if (!loginBtn || !regBtn) return;

    if (role === 'customer') {
      loginBtn.className = 'btn btn-gold btn-block';
      regBtn.className = 'btn btn-gold btn-block';
      if (loginIdLabel) loginIdLabel.textContent = 'البريد الإلكتروني أو رقم الهاتف';
      if (emailField) emailField.style.display = 'block';
      if (loginEmail) { loginEmail.value = ''; loginEmail.placeholder = 'you@example.com'; }
      if (merFields) merFields.style.display = 'none';
      if (tabReg) tabReg.style.display = 'block';
    } else if (role === 'merchant') {
      loginBtn.className = 'btn btn-green btn-block';
      regBtn.className = 'btn btn-green btn-block';
      if (loginIdLabel) loginIdLabel.textContent = 'بريد التاجر أو رقم الهاتف';
      if (emailField) emailField.style.display = 'block';
      if (loginEmail) { loginEmail.value = ''; loginEmail.placeholder = 'you@example.com'; }
      if (merFields) merFields.style.display = 'block';
      if (tabReg) tabReg.style.display = 'block';
    } else if (role === 'admin') {
      loginBtn.className = 'btn btn-purple btn-block';
      regBtn.className = 'btn btn-purple btn-block';
      if (emailField) emailField.style.display = 'none';
      if (loginEmail) loginEmail.value = '';
      if (loginPass) { loginPass.value = ''; loginPass.focus(); }
      if (merFields) merFields.style.display = 'none';
      if (tabReg) tabReg.style.display = 'none';
      if (loginForm) loginForm.style.display = 'block';
      if (regForm) regForm.style.display = 'none';
    }
  } catch (err) {
    console.error('selectRole error:', err);
  }
}

/* ---------- switchAuthTab ---------- */
function switchAuthTab(tab) {
  var t1 = $('tabLogin'), t2 = $('tabRegister');
  var lf = $('loginForm'), rf = $('registerForm');
  if (t1) t1.classList.toggle('active', tab === 'login');
  if (t2) t2.classList.toggle('active', tab === 'register');
  if (lf) lf.style.display = (tab === 'login') ? 'block' : 'none';
  if (rf) rf.style.display = (tab === 'register') ? 'block' : 'none';
}

/* ---------- handleLogin ---------- */
async function handleLogin() {
  var identifier, password;

  if (selectedLoginRole === 'admin') {
    identifier = ADMIN_EMAIL;
    password = $('loginPass').value;
    if (!password) return toast('أدخل كلمة مرور الإدارة', 'error');
  } else {
    identifier = $('loginEmail').value.trim();
    password = $('loginPass').value;
    if (!identifier || !password) return toast('أدخل البريد وكلمة المرور', 'error');
  }

  showLoading();
  try {
    var email = identifier;
    if (selectedLoginRole !== 'admin' && identifier.indexOf('@') === -1) {
      var look = await sb.rpc('lookup_user', { p_identifier: identifier });
      if (look.data && look.data.found) email = look.data.user.email;
    }

    var res = await sb.auth.signInWithPassword({ email: email, password: password });
    if (res.error) throw new Error('بيانات الدخول غير صحيحة');

    var user = await API.me();
    if (!user) throw new Error('فشل جلب البيانات');

    if (selectedLoginRole === 'admin' && user.role !== 'admin') {
      await API.logout(); throw new Error('هذا ليس حساب إدارة');
    }
    if (selectedLoginRole === 'merchant' && user.role !== 'merchant') {
      await API.logout(); throw new Error('هذا ليس حساب تاجر');
    }
    if (selectedLoginRole === 'customer' && user.role !== 'customer') {
      await API.logout(); throw new Error('استخدم بوابة الدخول الصحيحة');
    }

    currentUser = user;
    currentRole = user.role;
    toast('مرحباً ' + user.name, 'success');
    routeByRole();
  } catch (e) {
    toast(e.message, 'error');
    if (selectedLoginRole === 'admin') $('loginPass').value = '';
  } finally {
    hideLoading();
  }
}

/* ---------- handleRegister ---------- */
async function handleRegister() {
  var name = $('regName').value.trim();
  var phone = $('regPhone').value.trim();
  var email = $('regEmail').value.trim();
  var password = $('regPass').value;
  var bizEl = $('regBusinessName');
  var businessName = bizEl ? bizEl.value.trim() : '';

  if (!name || !phone || !email || !password) return toast('كل الحقول مطلوبة', 'error');
  if (password.length < 6) return toast('كلمة المرور قصيرة', 'error');
  if (selectedLoginRole === 'merchant' && !businessName) return toast('أدخل اسم المتجر', 'error');

  showLoading();
  try {
    var meta = { name: name, phone: phone, role: selectedLoginRole };
    if (selectedLoginRole === 'merchant') meta.business_name = businessName;

    var res = await sb.auth.signUp({
      email: email, password: password,
      options: { data: meta }
    });
    if (res.error) throw new Error(res.error.message);
    if (!res.data.user) throw new Error('فشل الإنشاء');

    await new Promise(function(r) { setTimeout(r, 1500); });

    var user = await API.me();
    if (!user) throw new Error('فشل جلب البيانات');

    currentUser = user;
    currentRole = user.role;
    toast('تم إنشاء الحساب 🎉', 'success');
    routeByRole();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ---------- handleLogout ---------- */
async function handleLogout() {
  await API.logout();
  currentUser = null;
  currentRole = 'customer';
  selectRole('customer');
  router.stack = [];
  router.go('screen-auth');
  toast('تم تسجيل الخروج');
}

/* ---------- routeByRole ---------- */
function routeByRole() {
  var nav = $('bottomNav');
  if (!nav) return;

  if (currentRole === 'merchant') {
    sb.from('profiles').select('merchant_status').eq('id', currentUser.id).single()
      .then(function(res) {
        var data = res.data;
        if (!data) return;
        if (data.merchant_status === 'pending') {
          nav.style.display = 'none';
          showPendingMerchant();
          return router.go('screen-merchant-pending');
        }
        if (data.merchant_status === 'rejected') {
          toast('حسابك مرفوض', 'error');
          return handleLogout();
        }
        nav.innerHTML =
          '<div class="nav-item active green" data-screen="screen-merchant" onclick="router.go(\'screen-merchant\')"><i class="fas fa-store"></i><span>لوحة</span></div>' +
          '<div class="nav-item" data-screen="screen-invest" onclick="router.go(\'screen-invest\')"><i class="fas fa-chart-line"></i><span>استثمار</span></div>' +
          '<div class="nav-item" data-screen="screen-history" onclick="router.go(\'screen-history\')"><i class="fas fa-list"></i><span>السجل</span></div>' +
          '<div class="nav-item" data-screen="screen-qr" onclick="router.go(\'screen-qr\')"><i class="fas fa-qrcode"></i><span>QR</span></div>' +
          '<div class="nav-item" data-screen="screen-api" onclick="router.go(\'screen-api\')"><i class="fas fa-code"></i><span>API</span></div>';
        router.go('screen-merchant');
      });
  } else if (currentRole === 'admin') {
    nav.innerHTML =
      '<div class="nav-item active purple" data-screen="screen-admin" onclick="router.go(\'screen-admin\')"><i class="fas fa-crown"></i><span>الإدارة</span></div>' +
      '<div class="nav-item" data-screen="screen-invest" onclick="router.go(\'screen-invest\')"><i class="fas fa-chart-line"></i><span>استثمار</span></div>' +
      '<div class="nav-item" data-screen="screen-history" onclick="router.go(\'screen-history\')"><i class="fas fa-list"></i><span>السجل</span></div>' +
      '<div class="nav-item" data-screen="screen-api" onclick="router.go(\'screen-api\')"><i class="fas fa-code"></i><span>API</span></div>';
    router.go('screen-admin');
  } else {
    nav.innerHTML =
      '<div class="nav-item active" data-screen="screen-home" onclick="router.go(\'screen-home\')"><i class="fas fa-home"></i><span>الرئيسية</span></div>' +
      '<div class="nav-item" data-screen="screen-invest" onclick="router.go(\'screen-invest\')"><i class="fas fa-chart-line"></i><span>استثمار</span></div>' +
      '<div class="nav-item" data-screen="screen-history" onclick="router.go(\'screen-history\')"><i class="fas fa-list"></i><span>السجل</span></div>' +
      '<div class="nav-item" data-screen="screen-qr" onclick="router.go(\'screen-qr\')"><i class="fas fa-qrcode"></i><span>QR</span></div>' +
      '<div class="nav-item" data-screen="screen-exchange" onclick="router.go(\'screen-exchange\')"><i class="fas fa-exchange-alt"></i><span>صرف</span></div>';
    router.go('screen-home');
  }
}

/* ---------- showPendingMerchant ---------- */
async function showPendingMerchant() {
  var info = $('pendingMerchantInfo');
  if (!info || !currentUser) return;
  var res = await sb.from('profiles')
    .select('business_name, name, phone, created_at')
    .eq('id', currentUser.id).single();
  if (res.data) {
    var d = new Date(res.data.created_at);
    info.innerHTML =
      '<div>🏪 ' + escapeHtml(res.data.business_name || '—') + '</div>' +
      '<div>👤 ' + escapeHtml(res.data.name) + '</div>' +
      '<div>📱 ' + escapeHtml(res.data.phone) + '</div>' +
      '<div style="font-size:11px;color:#94a3b8;margin-top:6px">أُرسل: ' + d.toLocaleDateString('ar-EG') + '</div>';
  }
}

/* ---------- Router ---------- */
var router = {
  stack: [],
  current: null,

  go: function(id) {
    if (this.current === id) return;
    if (this.current === 'screen-nfc' && id !== 'screen-nfc') {
      if (typeof cleanupNfc === 'function') cleanupNfc();
    }

    var screens = document.querySelectorAll('.screen');
    for (var i = 0; i < screens.length; i++) screens[i].classList.remove('active');

    var el = document.getElementById(id);
    if (!el) return;
    el.classList.add('active');

    if (this.current && this.current !== id) this.stack.push(this.current);
    this.current = id;

    var nav = $('bottomNav');
    if (nav) nav.style.display = (id === 'screen-auth') ? 'none' : 'flex';

    var navItems = document.querySelectorAll('.nav-item');
    for (var j = 0; j < navItems.length; j++) {
      navItems[j].classList.toggle('active', navItems[j].dataset.screen === id);
    }

    try {
      if (id === 'screen-home' && typeof renderCustomerHome === 'function') renderCustomerHome();
      if (id === 'screen-my-loans' && typeof renderMyLoans === 'function') renderMyLoans();
      if (id === 'screen-merchant' && typeof renderMerchantDash === 'function') renderMerchantDash();
      if (id === 'screen-admin' && typeof renderAdminDash === 'function') renderAdminDash();
      if (id === 'screen-history' && typeof renderHistory === 'function') renderHistory();
      if (id === 'screen-api' && typeof renderApi === 'function') renderApi();
      if (id === 'screen-qr' && typeof renderQR === 'function') renderQR();
      if (id === 'screen-exchange' && typeof renderExchange === 'function') renderExchange();
      if (id === 'screen-chat' && typeof renderChat === 'function') renderChat();
      if (id === 'screen-admin-chat' && typeof loadAdminConversations === 'function') loadAdminConversations();
      if (id === 'screen-invest' && typeof renderInvest === 'function') renderInvest();
      if (id === 'screen-my-shares' && typeof renderMyShares === 'function') renderMyShares();
      if (id === 'screen-nfc') {
        var s = $('nfcModeSelect');
        if (s) s.style.display = 'block';
      }
    } catch (err) {
      console.error('render error for', id, err);
    }
  },

  back: function() {
    var fallback = (currentRole === 'merchant') ? 'screen-merchant'
                 : (currentRole === 'admin') ? 'screen-admin'
                 : 'screen-home';
    var prev = this.stack.pop() || fallback;
    this.current = null;
    this.go(prev);
  }
};

/* ============================================================
   ✅ ربط الأزرار بـ addEventListener (يعمل دائماً)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function() {

  /* البطاقات */
  var roleCards = document.querySelectorAll('.role-card');
  for (var i = 0; i < roleCards.length; i++) {
    (function(card) {
      var role = card.dataset.role;
      if (!role) return;
      card.style.cursor = 'pointer';
      card.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        selectRole(role);
      });
    })(roleCards[i]);
  }

  /* تبويبات الدخول */
  var tLogin = $('tabLogin');
  var tReg = $('tabRegister');
  if (tLogin) tLogin.addEventListener('click', function(e) { e.preventDefault(); switchAuthTab('login'); });
  if (tReg) tReg.addEventListener('click', function(e) { e.preventDefault(); switchAuthTab('register'); });

  /* زر الدخول */
  var btnLogin = $('loginBtn');
  if (btnLogin) btnLogin.addEventListener('click', function(e) { e.preventDefault(); handleLogin(); });

  /* زر التسجيل */
  var btnReg = $('registerBtn');
  if (btnReg) btnReg.addEventListener('click', function(e) { e.preventDefault(); handleRegister(); });

  /* أيقونة البوابة */
  var shortcut = document.querySelector('.admin-shortcut');
  if (shortcut) {
    shortcut.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      openPortal();
    });
  }

  /* بطاقات البوابة */
  var portalMerchant = document.querySelector('.portal-card.merchant');
  var portalAdmin = document.querySelector('.portal-card.admin');
  if (portalMerchant) portalMerchant.addEventListener('click', function(e) { e.preventDefault(); pickPortalRole('merchant'); });
  if (portalAdmin) portalAdmin.addEventListener('click', function(e) { e.preventDefault(); pickPortalRole('admin'); });

  /* زر رجوع البوابة */
  var portalBack = document.querySelector('.portal-back');
  if (portalBack) portalBack.addEventListener('click', function(e) { e.preventDefault(); router.go('screen-auth'); });

  console.log('✅ 2-auth.js جاهز');
});