/* ============================================================
   أمان كاش — 5-nfc.js
   الدفع والاستقبال عبر NFC + تهيئة التطبيق
   ============================================================ */

/* هل المتصفح يدعم NFC؟ */
function isNfcSupported() {
  return 'NDEFReader' in window;
}

/* ============================================================
   اختيار وضع NFC (استقبال / دفع)
   ============================================================ */
function selectNfcMode(mode) {
  document.querySelectorAll('.nfc-mode-tab').forEach(t =>
    t.classList.toggle('active', t.dataset.mode === mode)
  );

  $('nfcModeSelect').style.display = 'none';

  if (mode === 'receive') {
    $('nfcReceiveUI').style.display = 'block';
    $('nfcPayUI').style.display = 'none';
    updateNfcReceiveData();
  } else {
    $('nfcReceiveUI').style.display = 'none';
    $('nfcPayUI').style.display = 'block';
  }
}

/* تحديث بيانات المستخدم في وضع الاستقبال */
function updateNfcReceiveData() {
  if (!currentUser) return;
  const el = $('nfcReceiveData');
  if (el) {
    el.textContent = `${currentUser.name || 'مستخدم'} · ${getUserIdentifier(currentUser)}`;
  }
}

/* ============================================================
   وضع الاستقبال (البث) — للتاجر
   ============================================================ */
async function startNfcBeacon() {
  const statusEl = $('nfcReceiveStatus'), circle = $('nfcReceiveCircle');
  const startBtn = $('nfcReceiveBtn'), stopBtn = $('nfcStopBtn');

  if (!isNfcSupported()) {
    statusEl.className = 'nfc-status error';
    statusEl.innerHTML = '❌ متصفحك لا يدعم NFC';
    return;
  }
  if (!currentUser) return toast('يجب تسجيل الدخول', 'error');

  const payload = QR_PREFIX + getUserIdentifier(currentUser);

  try {
    statusEl.className = 'nfc-status waiting';
    statusEl.innerHTML = '🔐 جاري طلب الصلاحية...';

    if (navigator.permissions && navigator.permissions.query) {
      try {
        const p = await navigator.permissions.query({ name: 'nfc' });
        if (p.state === 'denied') {
          statusEl.className = 'nfc-status error';
          statusEl.innerHTML = '❌ صلاحية NFC محظورة';
          return;
        }
      } catch (e) {}
    }

    nfcWriteController = new NDEFReader();
    statusEl.innerHTML = '⏳ جاري تفعيل البث...';

    await nfcWriteController.write({
      records: [{ recordType: 'text', data: payload, lang: 'ar' }]
    });

    circle.classList.add('active');
    statusEl.className = 'nfc-status success';
    statusEl.innerHTML = '✅ وضع الاستقبال نشط';
    startBtn.style.display = 'none';
    stopBtn.style.display = 'flex';
    toast('✅ وضع الاستقبال نشط', 'success');
  } catch (err) {
    statusEl.className = 'nfc-status error';
    statusEl.innerHTML = `❌ فشل: ${escapeHtml(err.message || '')}`;
  }
}

/* إيقاف البث */
function stopNfcBeacon() {
  const circle = $('nfcReceiveCircle'), statusEl = $('nfcReceiveStatus');
  if (circle) circle.classList.remove('active');
  if (statusEl) {
    statusEl.className = 'nfc-status waiting';
    statusEl.innerHTML = '⏳ تم الإيقاف';
  }
  if ($('nfcReceiveBtn')) $('nfcReceiveBtn').style.display = 'flex';
  if ($('nfcStopBtn')) $('nfcStopBtn').style.display = 'none';
  nfcWriteController = null;
}

/* ============================================================
   وضع الدفع (القراءة) — للعميل
   ============================================================ */
async function startNfcRead() {
  const statusEl = $('nfcPayStatus'), circle = $('nfcPayCircle');
  const startBtn = $('nfcPayBtn'), stopBtn = $('nfcPayStopBtn');

  if (!isNfcSupported()) {
    statusEl.className = 'nfc-status error';
    statusEl.innerHTML = '❌ متصفحك لا يدعم NFC';
    return;
  }

  try {
    statusEl.className = 'nfc-status waiting';
    statusEl.innerHTML = '📡 جاري الاستماع...';

    nfcAbortController = new AbortController();
    nfcScanController = new NDEFReader();

    await nfcScanController.scan({ signal: nfcAbortController.signal });

    circle.classList.add('active');
    startBtn.style.display = 'none';
    stopBtn.style.display = 'flex';

    nfcScanController.onreading = ({ message }) => {
      let detectedData = null;

      for (const record of message.records) {
        if (record.recordType === 'text') {
          try {
            const text = new TextDecoder(record.encoding || 'utf-8').decode(record.data);
            if (text.startsWith('amancash:')) {
              detectedData = text;
              break;
            }
          } catch (e) {}
        }
      }

      if (detectedData) handleNfcDataReceived(detectedData);
    };

    nfcScanController.onreadingerror = () => {
      statusEl.className = 'nfc-status error';
      statusEl.innerHTML = '❌ فشل القراءة';
    };
  } catch (err) {
    statusEl.className = 'nfc-status error';
    statusEl.innerHTML = `❌ فشل: ${escapeHtml(err.message || '')}`;
  }
}

/* إيقاف القراءة */
function stopNfcRead() {
  if (nfcAbortController) {
    try { nfcAbortController.abort(); } catch (e) {}
    nfcAbortController = null;
  }

  if (nfcScanController) {
    try {
      nfcScanController.onreading = null;
      nfcScanController.onreadingerror = null;
      nfcScanController = null;
    } catch (e) {}
  }

  const circle = $('nfcPayCircle'), statusEl = $('nfcPayStatus');
  const startBtn = $('nfcPayBtn'), stopBtn = $('nfcPayStopBtn');

  if (circle) circle.classList.remove('active');
  if (statusEl) {
    statusEl.className = 'nfc-status waiting';
    statusEl.innerHTML = '⏳ تم الإيقاف';
  }
  if (startBtn) startBtn.style.display = 'flex';
  if (stopBtn) stopBtn.style.display = 'none';
}

/* ============================================================
   معالجة البيانات المقروءة
   ============================================================ */
async function handleNfcDataReceived(data) {
  let identifier = data;
  if (identifier.startsWith(QR_PREFIX)) {
    identifier = identifier.substring(QR_PREFIX.length);
  }

  const user = await API.lookup(identifier);
  if (!user || !user.found) {
    $('nfcPayStatus').className = 'nfc-status error';
    $('nfcPayStatus').innerHTML = '❌ التاجر غير موجود';
    return;
  }

  $('nfcPayStatus').className = 'nfc-status success';
  $('nfcPayStatus').innerHTML = '✅ تم التعرف على التاجر';
  $('nfcDetected').style.display = 'flex';
  $('nfcDetectedValue').textContent = `${user.user.name} · ${identifier}`;
  $('nfcPayForm').style.display = 'block';

  nfcMerchantId = identifier;
  stopNfcRead();
  toast(`✅ ${user.user.name}`, 'success');
}

/* تنفيذ الدفع */
async function handleNfcPayment() {
  const to = nfcMerchantId;
  const amount = $('nfcAmount').value;

  if (!to) return toast('لم يتم التعرف على التاجر', 'error');
  if (!amount || Number(amount) <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');

  try {
    await API.transfer({ to, amount, note: 'دفع عبر NFC' });
    toast(`✅ تم الدفع ${formatNumber(amount)} OMNI`, 'success');

    $('nfcAmount').value = '';
    $('nfcDetected').style.display = 'none';
    $('nfcPayForm').style.display = 'none';
    $('nfcPayStatus').className = 'nfc-status waiting';
    $('nfcPayStatus').innerHTML = '⏳ جاهز للدفع مجدداً';
    nfcMerchantId = null;

    setTimeout(() => router.go('screen-home'), 2000);
  } catch (e) {
    toast(e.message, 'error');
  }
}

/* ============================================================
   تنظيف حالة NFC
   ============================================================ */
function cleanupNfc() {
  stopNfcBeacon();
  stopNfcRead();

  const select = $('nfcModeSelect'), recv = $('nfcReceiveUI'), pay = $('nfcPayUI');
  if (select) select.style.display = 'block';
  if (recv) recv.style.display = 'none';
  if (pay) pay.style.display = 'none';

  document.querySelectorAll('.nfc-mode-tab').forEach(t => t.classList.remove('active'));

  if ($('nfcDetected')) $('nfcDetected').style.display = 'none';
  if ($('nfcPayForm')) $('nfcPayForm').style.display = 'none';
  nfcMerchantId = null;
}

/* ============================================================
   التهيئة الأولية
   ============================================================ */
(async function init() {
  sb.auth.onAuthStateChange((event) => {
    if (event === 'SIGNED_OUT') {
      currentUser = null;
      currentRole = 'customer';
      router.go('screen-auth');
    }
  });

  const user = await API.me();
  if (user) {
    currentUser = user;
    currentRole = user.role || 'customer';
    routeByRole();
  } else {
    router.go('screen-auth');
  }
})();