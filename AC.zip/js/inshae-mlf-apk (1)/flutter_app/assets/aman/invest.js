/* ============================================================
   أمان كاش — 6-invest.js
   نظام الاستثمار: اكتتاب + تداول + إدارة + توزيع أرباح
   ============================================================ */

/* ============================================================
   شاشة الاستثمار الرئيسية — قائمة الإصدارات
   ============================================================ */
async function renderInvest() {
  const list = $('investList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_active_offerings');
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#94a3b8"><i class="fas fa-chart-line" style="font-size:48px;color:#cbd5e1;margin-bottom:14px;display:block"></i><div style="font-size:14px;font-weight:700;color:#64748b;margin-bottom:6px">لا توجد إصدارات حالياً</div><div style="font-size:12px">تابعنا لاحقاً لفرص استثمارية جديدة</div></div>';
      return;
    }

    list.innerHTML = data.map(function(o) {
      const remaining = Number(o.shares_remaining);
      const sold = Number(o.shares_sold);
      const total = Number(o.total_shares);
      const percent = total > 0 ? (sold / total) * 100 : 0;
      const statusInfo = getOfferingStatusInfo(o.status);
      const myQty = Number(o.my_quantity || 0);

      return `
        <div class="card invest-card" data-offering-id="${o.id}">
          <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:10px">
            <div style="flex:1;min-width:0">
              <div style="font-size:15px;font-weight:800;color:#0F172A;margin-bottom:4px">${escapeHtml(o.name)}</div>
              ${o.description ? '<div style="font-size:11px;color:#64748b;line-height:1.6">' + escapeHtml(o.description) + '</div>' : ''}
            </div>
            <span class="status-pill" style="background:${statusInfo.bg};color:${statusInfo.color}">${statusInfo.label}</span>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px">
            <div class="mini-stat">
              <div class="lbl">السعر</div>
              <div class="val">${formatNumber(o.price_per_share, 2)} <small>${o.currency}</small></div>
            </div>
            <div class="mini-stat">
              <div class="lbl">المتبقي</div>
              <div class="val">${formatNumber(remaining, 0)} <small>سهم</small></div>
            </div>
          </div>

          <div class="progress-bar-wrap">
            <div style="display:flex;justify-content:space-between;font-size:10.5px;color:#64748b;margin-bottom:4px">
              <span>تم اكتتاب ${formatNumber(sold, 0)} / ${formatNumber(total, 0)}</span>
              <span>${percent.toFixed(1)}%</span>
            </div>
            <div class="progress-bar">
              <div style="width:${percent}%;background:${statusInfo.barGradient}"></div>
            </div>
          </div>

          ${myQty > 0 ? '<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:8px;margin-top:10px;font-size:11px;color:#166534;display:flex;justify-content:space-between"><span>🎯 تملك: <b>' + formatNumber(myQty, 0) + ' سهم</b></span><span>استثمرت: <b>' + formatNumber(o.my_invested, 2) + ' ' + o.currency + '</b></span></div>' : ''}

          <button class="btn btn-gold btn-block" style="margin-top:10px" data-action="open-detail">
            <i class="fas fa-arrow-left"></i> التفاصيل والاكتتاب
          </button>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.invest-card').forEach(function(card) {
      const btn = card.querySelector('[data-action="open-detail"]');
      if (btn) {
        btn.addEventListener('click', function() {
          openOfferingDetail(Number(card.dataset.offeringId));
        });
      }
    });

  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

/* معلومات حالة الإصدار */
function getOfferingStatusInfo(status) {
  const map = {
    'active':   { label: '🟢 اكتتاب', bg: '#dcfce7', color: '#166534', barGradient: 'linear-gradient(90deg,#16a34a,#15803d)' },
    'sold_out': { label: '🔴 نفد',   bg: '#fee2e2', color: '#991b1b', barGradient: 'linear-gradient(90deg,#dc2626,#991b1b)' },
    'trading':  { label: '📊 تداول', bg: '#dbeafe', color: '#1e40af', barGradient: 'linear-gradient(90deg,#2563eb,#1d4ed8)' },
    'closed':   { label: '⬛ مغلق',  bg: '#f1f5f9', color: '#64748b', barGradient: 'linear-gradient(90deg,#64748b,#475569)' }
  };
  return map[status] || map['active'];
}

/* ============================================================
   تفاصيل الإصدار
   ============================================================ */
async function openOfferingDetail(offeringId) {
  router.go('screen-invest-detail');

  const content = $('investDetailContent');
  content.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_active_offerings');
    if (error) throw error;

    const o = (data || []).find(function(x) { return Number(x.id) === Number(offeringId); });
    if (!o) throw new Error('الإصدار غير موجود');

    $('investDetailTitle').textContent = o.name;
    $('investDetailStatus').textContent = getOfferingStatusInfo(o.status).label;

    const sold = Number(o.shares_sold);
    const total = Number(o.total_shares);
    const remaining = Number(o.shares_remaining);
    const percent = total > 0 ? (sold / total) * 100 : 0;
    const myQty = Number(o.my_quantity || 0);
    const statusInfo = getOfferingStatusInfo(o.status);

    content.innerHTML = `
      <div class="card" style="background:linear-gradient(135deg,#0F172A,#1E293B);color:#fff;border:none">
        <div style="font-size:11px;color:#94a3b8;margin-bottom:4px">السعر الحالي</div>
        <div style="font-size:32px;font-weight:800;color:#FCD34D;letter-spacing:-1px">
          ${formatNumber(o.price_per_share, 2)} <small style="font-size:14px">${o.currency}</small>
        </div>
        ${o.last_price && Number(o.last_price) !== Number(o.price_per_share) ? '<div style="font-size:11px;color:#94a3b8;margin-top:4px">آخر سعر تداول: ' + formatNumber(o.last_price, 2) + ' ' + o.currency + '</div>' : ''}
      </div>

      <div class="card">
        <div class="card-title"><i class="fas fa-info-circle"></i> معلومات الإصدار</div>
        ${o.description ? '<div style="font-size:12.5px;color:#475569;line-height:1.8;margin-bottom:12px">' + escapeHtml(o.description) + '</div>' : ''}
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div class="mini-stat"><div class="lbl">إجمالي الأسهم</div><div class="val">${formatNumber(total, 0)}</div></div>
          <div class="mini-stat"><div class="lbl">تم اكتتاب</div><div class="val" style="color:#16a34a">${formatNumber(sold, 0)}</div></div>
          <div class="mini-stat"><div class="lbl">المتبقي</div><div class="val" style="color:#dc2626">${formatNumber(remaining, 0)}</div></div>
          <div class="mini-stat"><div class="lbl">حد أدنى</div><div class="val">${formatNumber(o.min_per_user, 0)}</div></div>
          ${o.max_per_user ? '<div class="mini-stat" style="grid-column:span 2"><div class="lbl">حد أقصى لكل مستخدم</div><div class="val">' + formatNumber(o.max_per_user, 0) + ' سهم</div></div>' : ''}
        </div>
        <div class="progress-bar-wrap" style="margin-top:12px">
          <div style="display:flex;justify-content:space-between;font-size:10.5px;color:#64748b;margin-bottom:4px">
            <span>نسبة الاكتتاب</span><span>${percent.toFixed(1)}%</span>
          </div>
          <div class="progress-bar">
            <div style="width:${percent}%;background:${statusInfo.barGradient}"></div>
          </div>
        </div>
      </div>

      ${myQty > 0 ? '<div class="card" style="background:#f0fdf4;border:1px solid #86efac"><div style="font-size:13px;font-weight:800;color:#166534;margin-bottom:8px">💼 محفظتك من هذا الإصدار</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><div class="mini-stat"><div class="lbl">تملك</div><div class="val">' + formatNumber(myQty, 0) + ' سهم</div></div><div class="mini-stat"><div class="lbl">استثمرت</div><div class="val">' + formatNumber(o.my_invested, 2) + ' ' + o.currency + '</div></div></div></div>' : ''}

      ${o.status === 'active' ? `
        <div class="card">
          <div class="card-title"><i class="fas fa-shopping-cart"></i> اكتتب الآن</div>
          <div class="field">
            <label>عدد الأسهم (الحد الأدنى ${o.min_per_user})</label>
            <input type="number" id="subQty" placeholder="${o.min_per_user}" min="${o.min_per_user}" step="1">
          </div>
          <div id="subPreview" style="background:#FEF3C7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:12px;font-size:12px;color:#92400e;text-align:center;display:none">
            التكلفة الإجمالية: <b id="subTotal">0</b> <b id="subCurrency">${o.currency}</b>
          </div>
          <button class="btn btn-gold btn-block" data-action="subscribe">
            <i class="fas fa-check-circle"></i> تأكيد الاكتتاب
          </button>
        </div>
      ` : o.status === 'trading' ? `
        <div class="card">
          <div class="card-title"><i class="fas fa-exchange-alt"></i> التداول</div>
          <div style="font-size:12px;color:#64748b;margin-bottom:12px;text-align:center">
            هذا الإصدار متاح للتداول بين المستخدمين
          </div>
          <button class="btn btn-primary btn-block" data-action="open-market">
            <i class="fas fa-store"></i> دخول السوق
          </button>
          ${myQty > 0 ? '<button class="btn btn-outline btn-block" style="margin-top:8px" data-action="my-sell"><i class="fas fa-tag"></i> عرض أسهمي للبيع</button>' : ''}
        </div>
      ` : `
        <div class="card" style="text-align:center;padding:20px">
          <div style="font-size:13px;color:#64748b">
            ${o.status === 'sold_out' ? '🔴 نفد هذا الإصدار — بانتظار فتح التداول' : o.status === 'closed' ? '⬛ هذا الإصدار مغلق' : '—'}
          </div>
        </div>
      `}
    `;

    const subQtyInput = $('subQty');
    if (subQtyInput) {
      subQtyInput.addEventListener('input', function() { updateSubscribePreview(o); });
    }

    const subBtn = content.querySelector('[data-action="subscribe"]');
    if (subBtn) {
      subBtn.addEventListener('click', function() { submitSubscribe(offeringId, o); });
    }

    const marketBtn = content.querySelector('[data-action="open-market"]');
    if (marketBtn) {
      marketBtn.addEventListener('click', function() { renderMarket(offeringId); });
    }

    const mySellBtn = content.querySelector('[data-action="my-sell"]');
    if (mySellBtn) {
      mySellBtn.addEventListener('click', function() { renderMarket(offeringId); });
    }

  } catch (e) {
    content.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

function updateSubscribePreview(offering) {
  const qty = Number($('subQty').value) || 0;
  const preview = $('subPreview');
  if (qty > 0) {
    preview.style.display = 'block';
    $('subTotal').textContent = formatNumber(qty * Number(offering.price_per_share), 2);
    $('subCurrency').textContent = offering.currency;
  } else {
    preview.style.display = 'none';
  }
}

async function submitSubscribe(offeringId, offering) {
  const qty = Number($('subQty').value);
  if (!qty || qty <= 0) return toast('أدخل عدداً صحيحاً من الأسهم', 'error');

  if (!confirm('تأكيد اكتتاب ' + qty + ' سهم بسعر ' + formatNumber(offering.price_per_share, 2) + ' ' + offering.currency + '؟')) return;

  showLoading();
  try {
    const { data, error } = await sb.rpc('subscribe_to_offering', {
      p_offering_id: offeringId,
      p_quantity: qty
    });
    if (error) throw error;

    toast('✅ تم الاكتتاب: ' + data.quantity + ' سهم — التكلفة ' + formatNumber(data.total_cost, 2) + ' ' + data.currency, 'success');
    currentUser = null;
    await openOfferingDetail(offeringId);
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   محفظتي الاستثم��رية
   ============================================================ */
async function renderMyShares() {
  const list = $('mySharesList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_my_holdings');
    if (error) throw error;

    let totalValue = 0, totalInvested = 0;
    (data || []).forEach(function(h) {
      totalValue += Number(h.current_value || 0);
      totalInvested += Number(h.total_invested || 0);
    });
    const pnl = totalValue - totalInvested;

    $('mySharesCount').textContent = (data || []).length;
    $('mySharesValue').textContent = formatNumber(totalValue, 0);
    $('mySharesPnL').textContent = (pnl >= 0 ? '+' : '') + formatNumber(pnl, 0);

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#94a3b8"><i class="fas fa-briefcase" style="font-size:48px;color:#cbd5e1;margin-bottom:14px;display:block"></i><div style="font-size:14px;font-weight:700;color:#64748b;margin-bottom:6px">محفظتك فارغة</div><div style="font-size:12px">ابدأ بالاكتتاب من شاشة الاستثمار</div></div>';
      return;
    }

    list.innerHTML = data.map(function(h) {
      const pnlVal = Number(h.profit_loss || 0);
      const pnlPct = Number(h.profit_percent || 0);
      const isPos = pnlVal >= 0;

      return `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:10px">
            <div>
              <div style="font-size:14px;font-weight:800;color:#0F172A">${escapeHtml(h.offering_name)}</div>
              <div style="font-size:10.5px;color:#64748b">${getOfferingStatusInfo(h.status).label}</div>
            </div>
            <div style="text-align:left">
              <div style="font-size:14px;font-weight:800;color:${isPos ? '#16a34a' : '#dc2626'}">
                ${isPos ? '+' : ''}${formatNumber(pnlVal, 2)}
              </div>
              <div style="font-size:10.5px;color:${isPos ? '#16a34a' : '#dc2626'}">
                ${isPos ? '+' : ''}${pnlPct.toFixed(2)}%
              </div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;font-size:11px">
            <div class="mini-stat"><div class="lbl">الكمية</div><div class="val">${formatNumber(h.quantity, 0)}</div></div>
            <div class="mini-stat"><div class="lbl">متوسط الشراء</div><div class="val">${formatNumber(h.avg_price, 2)}</div></div>
            <div class="mini-stat"><div class="lbl">السعر الحالي</div><div class="val">${formatNumber(h.current_price, 2)}</div></div>
          </div>
          <div style="margin-top:10px;padding-top:10px;border-top:1px dashed #e2e8f0;display:flex;justify-content:space-between;font-size:11.5px">
            <span style="color:#64748b">القيمة الحالية</span>
            <span style="font-weight:800;color:#0F172A">${formatNumber(h.current_value, 2)} ${h.currency}</span>
          </div>
        </div>
      `;
    }).join('');

  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

/* ============================================================
   سوق التداول
   ============================================================ */
async function renderMarket(offeringId) {
  if (!offeringId) {
    toast('اختر إصداراً أولاً', 'error');
    return router.go('screen-invest');
  }

  window._marketOfferingId = offeringId;
  router.go('screen-market');

  try {
    const { data } = await sb.rpc('get_active_offerings');
    const o = (data || []).find(function(x) { return Number(x.id) === Number(offeringId); });
    if (o) $('marketOfferingName').textContent = o.name;
  } catch (e) {}

  const list = $('marketOrders');
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_open_orders', { p_offering_id: offeringId });
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">📭 لا توجد أوامر بيع حالياً</div>';
      return;
    }

    const myId = currentUser ? currentUser.id : null;

    list.innerHTML = data.map(function(o) {
      const isMine = o.seller_id === myId;
      return `
        <div class="card" style="${isMine ? 'background:#fef3c7;border-color:#fde68a' : ''}">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div>
              <div style="font-size:12.5px;font-weight:800;color:#0F172A">${escapeHtml(o.seller_name)}${isMine ? ' (أنت)' : ''}</div>
              <div style="font-size:10px;color:#94a3b8">${timeAgo(new Date(o.created_at).getTime())}</div>
            </div>
            <div style="text-align:left">
              <div style="font-size:14px;font-weight:800;color:#D97706">${formatNumber(o.price_per_share, 2)} <small>${o.currency}</small></div>
              <div style="font-size:10px;color:#64748b">للـ سهم</div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
            <div class="mini-stat"><div class="lbl">متاح</div><div class="val">${formatNumber(o.remaining, 0)} سهم</div></div>
            <div class="mini-stat"><div class="lbl">القيمة الإجمالية</div><div class="val">${formatNumber(o.total_value, 2)}</div></div>
          </div>
          ${isMine ? `
            <button data-action="cancel" data-order-id="${o.order_id}" class="btn btn-outline btn-block" style="color:#dc2626;border-color:#fecaca">
              <i class="fas fa-times"></i> إلغاء الأمر
            </button>
          ` : `
            <button data-action="buy" data-order-id="${o.order_id}" data-remaining="${o.remaining}" data-price="${o.price_per_share}" data-currency="${o.currency}" class="btn btn-green btn-block">
              <i class="fas fa-shopping-cart"></i> شراء
            </button>
          `}
        </div>
      `;
    }).join('');

    list.querySelectorAll('button[data-action]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        if (btn.dataset.action === 'buy') {
          openBuyModal(Number(btn.dataset.orderId), Number(btn.dataset.remaining), Number(btn.dataset.price), btn.dataset.currency);
        } else if (btn.dataset.action === 'cancel') {
          cancelMyOrder(Number(btn.dataset.orderId));
        }
      });
    });

  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function submitSellOrder() {
  const offeringId = window._marketOfferingId;
  const qty = Number($('sellQty').value);
  const price = Number($('sellPrice').value);

  if (!qty || qty <= 0) return toast('أدخل كمية صحيحة', 'error');
  if (!price || price <= 0) return toast('أدخل سعراً صحيحاً', 'error');
  if (!confirm('عرض ' + qty + ' سهم بسعر ' + formatNumber(price, 2) + ' لكل سهم؟')) return;

  showLoading();
  try {
    const { data, error } = await sb.rpc('place_sell_order', {
      p_offering_id: offeringId,
      p_quantity: qty,
      p_price: price
    });
    if (error) throw error;

    toast('✅ تم عرض الأسهم للبيع', 'success');
    $('sellQty').value = '';
    $('sellPrice').value = '';
    renderMarket(offeringId);
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

function openBuyModal(orderId, remaining, price, currency) {
  const modal = document.createElement('div');
  modal.className = 'qr-modal show';
  modal.id = 'buyShareModal';
  modal.innerHTML = `
    <div class="qr-modal-box">
      <button type="button" class="qr-close" onclick="closeBuyModal()"><i class="fas fa-times"></i></button>
      <h3>🛒 شراء أسهم</h3>
      <div style="background:#FEF3C7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#92400e;text-align:center">
        السعر: <b>${formatNumber(price, 2)} ${currency}</b> للـ سهم<br>
        متاح: <b>${formatNumber(remaining, 0)} سهم</b>
      </div>
      <div class="field">
        <label>الكمية</label>
        <input type="number" id="buyQty" placeholder="${remaining}" min="1" max="${remaining}" step="1">
      </div>
      <div id="buyTotalBox" style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#166534;text-align:center;display:none">
        الإجمالي: <b id="buyTotal">0</b> ${currency}
      </div>
      <button type="button" class="btn btn-green" onclick="submitBuy(${orderId}, ${price})">
        <i class="fas fa-check"></i> تأكيد الشراء
      </button>
      <button type="button" class="btn btn-outline" onclick="closeBuyModal()">
        <i class="fas fa-times"></i> إلغاء
      </button>
    </div>
  `;
  document.body.appendChild(modal);
  document.body.classList.add('modal-open');

  $('buyQty').addEventListener('input', function(e) {
    const q = Number(e.target.value);
    if (q > 0) {
      $('buyTotalBox').style.display = 'block';
      $('buyTotal').textContent = formatNumber(q * price, 2);
    } else {
      $('buyTotalBox').style.display = 'none';
    }
  });

  modal.addEventListener('click', function(e) { if (e.target === modal) closeBuyModal(); });
}

function closeBuyModal() {
  const m = $('buyShareModal');
  if (m) m.remove();
  document.body.classList.remove('modal-open');
}

async function submitBuy(orderId, price) {
  const qty = Number($('buyQty').value);
  if (!qty || qty <= 0) return toast('أدخل كمية صحيحة', 'error');
  if (!confirm('شراء ' + qty + ' سهم بسعر ' + formatNumber(price, 2) + ' لكل سهم؟')) return;

  showLoading();
  try {
    const { data, error } = await sb.rpc('buy_from_order', {
      p_order_id: orderId,
      p_quantity: qty
    });
    if (error) throw error;

    toast('✅ تم الشراء: ' + data.quantity + ' سهم — الإجمالي ' + formatNumber(data.total, 2) + ' ' + data.currency, 'success');
    closeBuyModal();
    currentUser = null;
    renderMarket(window._marketOfferingId);
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function cancelMyOrder(orderId) {
  if (!confirm('هل تريد إلغاء هذا الأمر؟')) return;
  showLoading();
  try {
    const { error } = await sb.rpc('cancel_sell_order', { p_order_id: orderId });
    if (error) throw error;
    toast('تم إلغاء الأمر', 'success');
    renderMarket(window._marketOfferingId);
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   لوحة الإدارة — تبويب الأسهم
   ============================================================ */
async function loadAdminShares() {
  const list = $('adminSharesList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('admin_get_all_offerings');
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">📭 لا توجد إصدارات</div>';
      return;
    }

    list.innerHTML = data.map(function(o) {
      const statusInfo = getOfferingStatusInfo(o.status);
      const sold = Number(o.shares_sold);
      const total = Number(o.total_shares);
      const percent = total > 0 ? (sold / total) * 100 : 0;

      return `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:10px">
            <div style="flex:1">
              <div style="font-size:14px;font-weight:800;color:#0F172A">${escapeHtml(o.name)}</div>
              <div style="font-size:10.5px;color:#94a3b8">#${o.id} · ${new Date(o.created_at).toLocaleDateString('ar-EG')}</div>
            </div>
            <span class="status-pill" style="background:${statusInfo.bg};color:${statusInfo.color}">${statusInfo.label}</span>
          </div>

          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:10px">
            <div class="mini-stat"><div class="lbl">السعر</div><div class="val">${formatNumber(o.price_per_share, 2)}</div></div>
            <div class="mini-stat"><div class="lbl">مباع</div><div class="val">${formatNumber(sold, 0)}</div></div>
            <div class="mini-stat"><div class="lbl">متبقي</div><div class="val">${formatNumber(o.shares_remaining, 0)}</div></div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px;margin-bottom:10px">
            <div style="background:#f8fafc;padding:6px;border-radius:8px;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px">المساهمون</div>
              <div style="font-weight:800">${formatNumber(o.unique_holders, 0)}</div>
            </div>
            <div style="background:#f8fafc;padding:6px;border-radius:8px;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px">حجم التداول</div>
              <div style="font-weight:800">${formatNumber(o.total_volume, 0)} ${o.currency}</div>
            </div>
          </div>

          <div class="progress-bar-wrap" style="margin-bottom:10px">
            <div class="progress-bar"><div style="width:${percent}%;background:${statusInfo.barGradient}"></div></div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
            ${o.status === 'trading' || o.status === 'sold_out' ? `
              <button data-action="dividend" data-id="${o.id}" data-name="${escapeAttr(o.name)}" class="btn" style="background:linear-gradient(135deg,#FCD34D,#D97706);color:#fff;padding:8px;font-size:11px;grid-column:span 2">
                <i class="fas fa-hand-holding-usd"></i> توزيع أرباح
              </button>
            ` : ''}
            ${o.status === 'active' || o.status === 'sold_out' ? `
              <button data-action="open-trading" data-id="${o.id}" class="btn btn-primary" style="padding:8px;font-size:11px">
                <i class="fas fa-play"></i> فتح التداول
              </button>
            ` : ''}
            ${o.status !== 'closed' ? `
              <button data-action="close" data-id="${o.id}" class="btn" style="background:#fee2e2;color:#dc2626;padding:8px;font-size:11px">
                <i class="fas fa-times"></i> إغلاق
              </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('button[data-action]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const id = Number(btn.dataset.id);
        if (btn.dataset.action === 'open-trading') openTradingForOffering(id);
        if (btn.dataset.action === 'close') closeOffering(id);
        if (btn.dataset.action === 'dividend') openDistributeDividends(id, btn.dataset.name);
      });
    });

  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function openTradingForOffering(id) {
  if (!confirm('هل تريد فتح التداول على هذا الإصدار؟')) return;
  showLoading();
  try {
    const { error } = await sb.rpc('admin_open_trading', { p_offering_id: id });
    if (error) throw error;
    toast('✅ تم فتح التداول', 'success');
    loadAdminShares();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function closeOffering(id) {
  if (!confirm('هل تريد إغلاق هذا الإصدار؟ سيتم إلغاء كل أوامر البيع المفتوحة.')) return;
  showLoading();
  try {
    const { error } = await sb.rpc('admin_close_offering', { p_offering_id: id });
    if (error) throw error;
    toast('تم إغلاق الإصدار', 'success');
    loadAdminShares();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

function openCreateOffering() {
  const modal = document.createElement('div');
  modal.className = 'qr-modal show';
  modal.id = 'createOfferingModal';
  modal.innerHTML = `
    <div class="qr-modal-box">
      <button type="button" class="qr-close" onclick="closeCreateOffering()"><i class="fas fa-times"></i></button>
      <h3>📈 إصدار أسهم جديد</h3>
      <div class="field"><label>اسم الإصدار</label><input id="offName" placeholder="إصدار 2026"></div>
      <div class="field"><label>الوصف (اختياري)</label><input id="offDesc" placeholder="وصف مختصر"></div>
      <div class="field"><label>إجمالي الأسهم</label><input type="number" id="offTotal" placeholder="10000" min="1"></div>
      <div class="field"><label>سعر السهم</label><input type="number" id="offPrice" placeholder="10.00" step="0.01" min="0.01"></div>
      <div class="field"><label>العملة</label>
        <select id="offCurrency">
          <option value="OMNI">💠 OMNI</option>
          <option value="USD">$ USD</option>
          <option value="SYP">ل.س SYP</option>
          <option value="EUR">€ EUR</option>
        </select>
      </div>
      <div class="field"><label>حد أدنى لكل مستخدم</label><input type="number" id="offMin" value="1" min="1"></div>
      <div class="field"><label>حد أقصى لكل مستخدم (اختياري)</label><input type="number" id="offMax" placeholder="اتركه فارغاً لإلغاء الحد" min="1"></div>
      <button type="button" class="btn btn-gold" onclick="submitCreateOffering()">
        <i class="fas fa-check"></i> إنشاء الإصدار
      </button>
      <button type="button" class="btn btn-outline" onclick="closeCreateOffering()">
        <i class="fas fa-times"></i> إلغاء
      </button>
    </div>
  `;
  document.body.appendChild(modal);
  document.body.classList.add('modal-open');
  modal.addEventListener('click', function(e) { if (e.target === modal) closeCreateOffering(); });
}

function closeCreateOffering() {
  const m = $('createOfferingModal');
  if (m) m.remove();
  document.body.classList.remove('modal-open');
}

async function submitCreateOffering() {
  const name = $('offName').value.trim();
  const desc = $('offDesc').value.trim() || null;
  const total = Number($('offTotal').value);
  const price = Number($('offPrice').value);
  const currency = $('offCurrency').value;
  const minU = Number($('offMin').value) || 1;
  const maxU = $('offMax').value ? Number($('offMax').value) : null;

  if (!name) return toast('أدخل اسم الإصدار', 'error');
  if (!total || total <= 0) return toast('أدخل عدد أسهم صحيح', 'error');
  if (!price || price <= 0) return toast('أدخل سعراً صحيحاً', 'error');

  showLoading();
  try {
    const { data, error } = await sb.rpc('admin_create_offering', {
      p_name: name,
      p_total_shares: total,
      p_price: price,
      p_currency: currency,
      p_description: desc,
      p_min_per_user: minU,
      p_max_per_user: maxU,
      p_ends_at: null
    });
    if (error) throw error;

    toast('✅ تم إنشاء الإصدار', 'success');
    closeCreateOffering();
    loadAdminShares();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   💰 توزيع الأرباح
   ============================================================ */
async function openDistributeDividends(offeringId, offeringName) {
  if (!await requireAdmin()) return;

  let modal = $('dividendModal');
  if (!modal) {
    const html = `
      <div class="qr-modal" id="dividendModal">
        <div class="qr-modal-box">
          <button type="button" class="qr-close" onclick="closeDividendModal()"><i class="fas fa-times"></i></button>
          <h3>💰 توزيع أرباح</h3>
          <div style="background:#FEF3C7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#92400e;text-align:center">
            الإصدار: <b id="divOfferingName">—</b>
          </div>
          <div class="field">
            <label>المبلغ الإجمالي</label>
            <input type="number" id="divAmount" placeholder="1000" min="1" step="0.01">
          </div>
          <div class="field">
            <label>العملة</label>
            <select id="divCurrency">
              <option value="OMNI">💠 OMNI</option>
              <option value="USD">$ USD</option>
              <option value="SYP">ل.س SYP</option>
              <option value="EUR">€ EUR</option>
            </select>
          </div>
          <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#166534">
            💡 سيُوزَّع المبلغ على كل حاملي الأسهم بنسبة عدد أسهم كل منهم
          </div>
          <button type="button" class="btn btn-gold" onclick="submitDistributeDividends(${offeringId})">
            <i class="fas fa-check-circle"></i> تأكيد التوزيع
          </button>
          <button type="button" class="btn btn-outline" onclick="closeDividendModal()">
            <i class="fas fa-times"></i> إلغاء
          </button>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    modal = $('dividendModal');
    modal.addEventListener('click', function(e) { if (e.target === modal) closeDividendModal(); });
  }

  $('divOfferingName').textContent = offeringName;
  $('divAmount').value = '';
  $('divCurrency').value = 'OMNI';
  modal.classList.add('show');
  document.body.classList.add('modal-open');

  const escHandler = function(e) {
    if (e.key === 'Escape') { closeDividendModal(); document.removeEventListener('keydown', escHandler); }
  };
  document.addEventListener('keydown', escHandler);
}

function closeDividendModal() {
  const m = $('dividendModal');
  if (m) m.classList.remove('show');
  document.body.classList.remove('modal-open');
}

async function submitDistributeDividends(offeringId) {
  const amount = Number($('divAmount').value);
  const currency = $('divCurrency').value;

  if (!amount || amount <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');
  if (!confirm('توزيع ' + formatNumber(amount) + ' ' + currency + ' على حاملي الأسهم؟')) return;

  showLoading();
  try {
    const { data, error } = await sb.rpc('admin_distribute_dividends', {
      p_offering_id: offeringId,
      p_total_amount: amount,
      p_currency: currency
    });
    if (error) throw error;

    toast('✅ تم توزيع ' + formatNumber(data.distributed) + ' ' + data.currency + ' على ' + data.holders + ' مساهم', 'success');
    closeDividendModal();
    if (typeof loadAdminShares === 'function') loadAdminShares();
    if (typeof loadTreasury === 'function') loadTreasury();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}