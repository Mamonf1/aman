import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AmanCashApp());
}

class AmanCashApp extends StatelessWidget {
  const AmanCashApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'أمان كاش',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD97706),
          brightness: Brightness.dark,
        ),
      ),
      home: const AmanWebView(),
    );
  }
}

class AmanWebView extends StatefulWidget {
  const AmanWebView({super.key});

  @override
  State<AmanWebView> createState() => _AmanWebViewState();
}

class _AmanWebViewState extends State<AmanWebView> {
  late final WebViewController controller;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0F172A))
      ..enableZoom(false)
      ..loadFlutterAsset('assets/aman/index.html');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(child: WebViewWidget(controller: controller)),
    );
  }
}
