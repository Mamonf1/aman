/* ============================================================
   أمان كاش — 3-customer.js
   شاشات العميل: الرئيسية + القروض + QR + الإرسال + الصرف + API + التاجر
   ============================================================ */

/* ============================================================
   الصفحة الرئيسية للعميل
   ============================================================ */
async function renderCustomerHome() {
  currentUser = await API.me();
  if (!currentUser) return router.go('screen-auth');

  $('homeBalance').innerHTML = `${formatNumber(currentUser.balanceOmni)} <small>OMNI</small>`;

  const usdTotal =
    currentUser.balanceOmni * 0.05 +
    currentUser.balanceUsd +
    currentUser.balanceSyp * 0.0000667 +
    currentUser.balanceEur * 1.08;
  $('homeUsd').textContent = `≈ $${formatNumber(usdTotal)}`;
  $('homeAccount').textContent = currentUser.accountNumber || '—';

  /* شارة VIP */
  const balLabel = document.querySelector('.balance-label');
  if (balLabel) {
    if (currentUser.userType === 'vip') {
      balLabel.innerHTML = 'الرصيد الكلي <span style="background:linear-gradient(135deg,#FCD34D,#D97706);color:#fff;padding:2px 8px;border-radius:10px;font-size:9px;font-weight:800;margin-right:4px">⭐ VIP</span>';
    } else {
      balLabel.textContent = 'الرصيد الكلي';
    }
  }

  renderCurrencyTabs('currencyTabs', currentUser);

  const txs = (await API.transactions()).transactions;
  $('homeTxList').innerHTML = txs.length
    ? txs.slice(0, 4).map(txHTML).join('')
    : '<div style="padding:24px;text-align:center;color:#94a3b8;font-size:13px">لا توجد عمليات</div>';
}

/* بطاقات العملات الأربعة */
function renderCurrencyTabs(targetId, user) {
  const el = document.getElementById(targetId);
  if (!el) return;
  el.innerHTML = `
    <div class="currency-tab"><span class="sym">💠</span><div class="code">OMNI</div><div class="amount">${formatNumber(user.balanceOmni, 2)}</div></div>
    <div class="currency-tab"><span class="sym">$</span><div class="code">USD</div><div class="amount">${formatNumber(user.balanceUsd, 2)}</div></div>
    <div class="currency-tab"><span class="sym">ل.س</span><div class="code">SYP</div><div class="amount">${formatNumber(user.balanceSyp, 0)}</div></div>
    <div class="currency-tab"><span class="sym">€</span><div class="code">EUR</div><div class="amount">${formatNumber(user.balanceEur, 2)}</div></div>
  `;
}

/* قالب HTML لعملية واحدة */
function txHTML(tx) {
  const isIn = tx.type === 'in';
  return `<div class="tx-item">
    <div class="tx-icon ${isIn ? 'in' : 'out'}"><i class="fas fa-arrow-${isIn ? 'down' : 'up'}"></i></div>
    <div class="tx-info"><div class="nm">${escapeHtml(tx.title)}</div><div class="dt">${timeAgo(tx.date)}</div></div>
    <div class="tx-amt ${isIn ? 'plus' : 'minus'}">${isIn ? '+' : '-'} ${formatNumber(tx.amount)}</div>
  </div>`;
}

/* ============================================================
   قروضي (شاشة العميل)
   ============================================================ */
async function renderMyLoans() {
  const list = $('myLoansList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const bal = await API.balance();
    const balEl = $('myLoansBalance');
    if (balEl) balEl.innerHTML = `${formatNumber(bal.balanceOmni, 2)} <small>OMNI</small>`;

    const { data, error } = await sb.rpc('get_my_loans');
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">🎉 ليس لديك أي قروض</div>';
      return;
    }

    const statusMap = {
      'active':    { color: '#dcfce7', text: '#166534', label: '🟢 نشط' },
      'paid':      { color: '#dbeafe', text: '#1e40af', label: '✅ مسدد' },
      'defaulted': { color: '#fee2e2', text: '#991b1b', label: '❌ متعثر' },
      'cancelled': { color: '#f1f5f9', text: '#64748b', label: '🚫 ملغي' }
    };

    list.innerHTML = data.map(l => {
      const s = statusMap[l.status] || statusMap['active'];
      const progress = l.total_due > 0
        ? Math.min(100, (l.paid_amount / l.total_due) * 100)
        : 0;

      return `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px;margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <div style="font-size:13px;font-weight:800;color:#0F172A">قرض #${l.id}</div>
            <span style="background:${s.color};color:${s.text};padding:3px 10px;border-radius:8px;font-size:10px;font-weight:700">${s.label}</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:10px;font-size:11px">
            <div style="background:#fff;padding:8px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">القرض</div>
              <div style="font-weight:800;color:#0F172A">${formatNumber(l.amount, 0)}</div>
            </div>
            <div style="background:#fff;padding:8px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">دفعت</div>
              <div style="font-weight:800;color:#16a34a">${formatNumber(l.paid_amount, 0)}</div>
            </div>
            <div style="background:#fff;padding:8px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">المتبقي</div>
              <div style="font-weight:800;color:#dc2626">${formatNumber(l.remaining, 0)}</div>
            </div>
          </div>
          <div style="background:#fff;border-radius:8px;padding:8px;margin-bottom:10px">
            <div style="display:flex;justify-content:space-between;font-size:10.5px;color:#64748b;margin-bottom:4px">
              <span>التقدم</span><span>${progress.toFixed(0)}%</span>
            </div>
            <div style="height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden">
              <div style="height:100%;width:${progress}%;background:linear-gradient(90deg,#16a34a,#15803d);border-radius:3px"></div>
            </div>
          </div>
          ${l.status === 'active' ? `
            <button data-loan-id="${l.id}" data-loan-remaining="${l.remaining}" class="btn-pay-loan" style="width:100%;background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;border:none;padding:10px;border-radius:10px;font-family:'Cairo';font-weight:800;font-size:12px;cursor:pointer">
              <i class="fas fa-money-bill-wave"></i> سداد القسط
            </button>
          ` : ''}
        </div>
      `;
    }).join('');

    list.querySelectorAll('.btn-pay-loan').forEach(btn => {
      btn.addEventListener('click', () => {
        openPayMyLoan(Number(btn.dataset.loanId), Number(btn.dataset.loanRemaining));
      });
    });

  } catch (e) {
    list.innerHTML = `<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ${escapeHtml(e.message)}</div>`;
  }
}

/* نافذة سداد القسط */
async function openPayMyLoan(loanId, remaining) {
  let modal = $('payMyLoanModal');

  if (!modal) {
    const html = `
      <div class="qr-modal" id="payMyLoanModal">
        <div class="qr-modal-box">
          <button type="button" class="qr-close" onclick="closePayMyLoan()"><i class="fas fa-times"></i></button>
          <h3>💳 سداد القسط</h3>
          <div style="background:#FEF3C7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#92400e;text-align:center">
            <b>المتبقي:</b> <span id="payLoanRemaining">0</span> OMNI
          </div>
          <div class="field">
            <label>المبلغ المراد سداده</label>
            <input type="number" id="payMyLoanAmount" placeholder="0.00" min="1" step="0.01">
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:14px">
            <button type="button" data-ratio="0.25" class="btn-ratio" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">25%</button>
            <button type="button" data-ratio="0.5" class="btn-ratio" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">50%</button>
            <button type="button" data-ratio="1" class="btn-ratio" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">100%</button>
          </div>
          <button type="button" class="btn btn-gold" onclick="submitPayMyLoan()"><i class="fas fa-check"></i> تأكيد السداد</button>
          <button type="button" class="btn btn-outline" onclick="closePayMyLoan()"><i class="fas fa-times"></i> إلغاء</button>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    modal = $('payMyLoanModal');
    modal.addEventListener('click', (e) => { if (e.target === modal) closePayMyLoan(); });
    modal.querySelectorAll('.btn-ratio').forEach(b => {
      b.addEventListener('click', () => setPayAmount(Number(b.dataset.ratio)));
    });
  }

  window._payLoanId = loanId;
  window._payLoanRemaining = remaining;
  $('payLoanRemaining').textContent = formatNumber(remaining, 2);
  $('payMyLoanAmount').value = '';
  modal.classList.add('show');
  document.body.classList.add('modal-open');

  const escHandler = (e) => {
    if (e.key === 'Escape') {
      closePayMyLoan();
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);
}

function setPayAmount(ratio) {
  const remaining = window._payLoanRemaining || 0;
  $('payMyLoanAmount').value = (remaining * ratio).toFixed(2);
}

function closePayMyLoan() {
  const m = $('payMyLoanModal');
  if (m) m.classList.remove('show');
  document.body.classList.remove('modal-open');
}

async function submitPayMyLoan() {
  const loanId = window._payLoanId;
  const amount = Number($('payMyLoanAmount').value);

  if (!loanId) return toast('خطأ في الجلسة', 'error');
  if (!amount || amount <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');

  showLoading();
  try {
    const { data, error } = await sb.rpc('customer_pay_loan', {
      p_loan_id: loanId,
      p_amount: amount
    });
    if (error) throw error;

    toast(`✅ تم سداد ${formatNumber(data.paid_amount ?? amount)} OMNI`, 'success');
    closePayMyLoan();
    await renderMyLoans();
    await renderCustomerHome();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   QR الثابت
   ============================================================ */
function buildQRPayload(user) {
  return QR_PREFIX + getUserIdentifier(user);
}

async function renderQR() {
  currentUser = currentUser || await API.me();
  if (!currentUser) return;

  const box = $('staticQR');
  box.innerHTML = '';

  const identifier = getUserIdentifier(currentUser);
  try {
    new QRCode(box, {
      text: QR_PREFIX + identifier,
      width: 200, height: 200,
      colorDark: '#0F172A', colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
    });
  } catch (e) {}

  $('staticQRId').innerHTML = `
    <div style="font-size:11px;color:#64748b;margin-bottom:4px">رقم حسابك</div>
    <div style="font-size:18px;font-weight:800;color:#0F172A;letter-spacing:2px;font-family:monospace">${escapeHtml(identifier)}</div>
    <div style="font-size:10px;color:#94a3b8;margin-top:4px">${escapeHtml(currentUser.name || '')}</div>
  `;
}

/* ============================================================
   إرسال أموال
   ============================================================ */
function openSend() {
  router.go('screen-send');
  $('sendTo').value = '';
  $('sendAmount').value = '';
  $('sendNote').value = '';
}

async function handleSend() {
  const to = $('sendTo').value.trim();
  const amount = $('sendAmount').value;
  const note = $('sendNote').value.trim();

  if (!to) return toast('أدخل المستلم', 'error');
  if (!amount || Number(amount) <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');

  try {
    await API.transfer({ to, amount, note });
    toast(`تم إرسال ${formatNumber(amount)} OMNI ✅`, 'success');
    router.back();
  } catch (e) {
    toast(e.message, 'error');
  }
}

/* ============================================================
   صرف العملات
   ============================================================ */
function renderExchange() {
  const el = $('ratesList');
  el.innerHTML = Object.values(CURRENCIES).map(c => `
    <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:13px">
      <span><span style="font-size:16px">${c.symbol}</span> ${c.name}</span>
      <span style="font-weight:800">${formatNumber(c.usdRate, 5)} $</span>
    </div>
  `).join('');
}

function previewExchange() {
  const from = $('exFrom').value, to = $('exTo').value;
  const amount = Number($('exAmount').value);

  if (!amount || amount <= 0 || from === to) {
    $('exPreview').style.display = 'none';
    return;
  }

  const rate = CURRENCIES[from].usdRate / CURRENCIES[to].usdRate;
  const result = (amount - amount * EXCHANGE_FEE_RATE) * rate;

  $('exPreview').style.display = 'block';
  $('exResult').textContent = `${formatNumber(result, (from === 'SYP' || to === 'SYP') ? 0 : 2)} ${to}`;
  $('exRate').textContent = `1 ${from} = ${formatNumber(rate, from === 'SYP' ? 6 : 4)} ${to}`;
}

async function executeExchange() {
  const from = $('exFrom').value, to = $('exTo').value;
  const amount = Number($('exAmount').value);

  if (!amount || amount <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');
  if (from === to) return toast('اختر عملتين مختلفتين', 'error');

  try {
    const res = await API.exchange({ from, to, amount });
    toast(`تم الصرف: ${formatNumber(res.to_amount)} ${to} ✅`, 'success');
    $('exAmount').value = '';
    $('exPreview').style.display = 'none';
    currentUser = null;
    setTimeout(() => router.back(), 1200);
  } catch (e) {
    toast(e.message, 'error');
  }
}

/* ============================================================
   شاشة API (للتاجر والإدارة)
   ============================================================ */
async function renderApi() {
  currentUser = currentUser || await API.me();
  if (!currentUser) return;

  if (currentUser.role !== 'merchant' && currentUser.role !== 'admin') {
    toast('غير مصرح', 'error');
    return router.back();
  }

  $('apiKeyBox').textContent = currentUser.apiKey || '—';
}

function copyApiKey() {
  if (!currentUser || !currentUser.apiKey) return toast('غير متاح', 'error');
  navigator.clipboard?.writeText(currentUser.apiKey).then(
    () => toast('تم النسخ ✅', 'success'),
    () => toast('تعذر النسخ', 'error')
  );
}

/* ============================================================
   السجل الكامل
   ============================================================ */
async function renderHistory() {
  const txs = (await API.transactions()).transactions;
  $('fullTxList').innerHTML = txs.length
    ? txs.map(txHTML).join('')
    : '<div style="padding:30px;text-align:center;color:#94a3b8">لا توجد عمليات</div>';
}

/* ============================================================
   لوحة التاجر
   ============================================================ */
async function renderMerchantDash() {
  currentUser = await API.me();
  if (!currentUser) return router.go('screen-auth');
  if (currentUser.merchantStatus === 'pending') return router.go('screen-merchant-pending');

  $('merchantBizName').textContent = currentUser.businessName || currentUser.name;
  $('mBalance').textContent = formatNumber(currentUser.balanceOmni, 0);

  const txs = (await API.transactions()).transactions;

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayTxs = txs.filter(t => t.date >= today.getTime() && t.type === 'in');
  $('mSalesToday').textContent = formatNumber(todayTxs.reduce((s, t) => s + t.amount, 0), 0);
  $('mOrdersToday').textContent = todayTxs.length;

  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const monthTxs = txs.filter(t => t.date >= monthStart.getTime() && t.type === 'in');
  $('mMonthSales').textContent = formatNumber(monthTxs.reduce((s, t) => s + t.amount, 0), 0) + ' OMNI';
  $('mMonthCustomers').textContent = monthTxs.length;

  renderCurrencyTabs('merchantCurrencyTabs', currentUser);

  $('merchantTxList').innerHTML = txs.length
    ? txs.slice(0, 5).map(txHTML).join('')
    : '<div style="padding:24px;text-align:center;color:#94a3b8;font-size:13px">لا توجد عمليات</div>';
}