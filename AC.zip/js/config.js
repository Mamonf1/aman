/* ============================================================
   أمان كاش — 1-config.js
   الإعدادات + Helpers + API + بوابة الدخول + مؤشر الاتصال
   ============================================================ */

/* ---------- إعدادات Supabase ---------- */
const SUPABASE_URL = 'https://nnuwunzyufsiszfgwdmv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5udXd1bnp5dWZzaXN6Zmd3ZG12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk3ODcwNjYsImV4cCI6MjEwNTM2MzA2Nn0.VBjD0seZSpYjAqzW43bAG0Kbgj-a7zZW4DAYwpALCAA';

/* ---------- الرسوم ---------- */
const TRANSFER_FEE_RATE = 0.005;
const EXCHANGE_FEE_RATE = 0.005;
const TRADE_FEE_RATE = 0.005;
const FEE = TRANSFER_FEE_RATE;

/* ---------- ثوابت عامة ---------- */
const QR_PREFIX = 'amancash:v2:OMNI:';
const ADMIN_EMAIL = 'omniamarkeet@gmail.com';

/* ---------- العملات المدعومة ---------- */
const CURRENCIES = {
  OMNI: { code: 'OMNI', name: 'أومني',      symbol: '💠',  usdRate: 0.05 },
  USD:  { code: 'USD',  name: 'دولار',      symbol: '$',   usdRate: 1 },
  SYP:  { code: 'SYP',  name: 'ليرة سورية', symbol: 'ل.س', usdRate: 0.0000667 },
  EUR:  { code: 'EUR',  name: 'يورو',       symbol: '€',   usdRate: 1.08 },
};

/* ---------- عميل Supabase ---------- */
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/* ---------- متغيرات الحالة العامة ---------- */
var currentUser = null;
var currentRole = 'customer';
var selectedLoginRole = 'customer';
var currentConversationId = null;
var adminViewingConvId = null;
var nfcScanController = null;
var nfcWriteController = null;
var nfcAbortController = null;
var nfcMerchantId = null;
var adminAccessCounter = 0;
var adminAccessTimer = null;
var adminCardVisible = false;

/* ============================================================
   دوال مساعدة عامة
   ============================================================ */

function $(id) {
  return document.getElementById(id);
}

function showLoading() {
  const l = $('loading');
  if (l) l.classList.add('show');
}

function hideLoading() {
  const l = $('loading');
  if (l) l.classList.remove('show');
}

var toastTimer;
function toast(msg, type) {
  type = type || '';
  const t = $('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function() { t.className = 'toast ' + type; }, 3000);
}

function formatNumber(n, d) {
  d = (d === undefined) ? 2 : d;
  return Number(n || 0).toLocaleString('en-US', {
    minimumFractionDigits: d,
    maximumFractionDigits: d
  });
}

function timeAgo(ts) {
  const d = Math.floor((Date.now() - ts) / 1000);
  if (d < 60) return 'الآن';
  if (d < 3600) return 'قبل ' + Math.floor(d / 60) + ' دقيقة';
  if (d < 86400) return 'قبل ' + Math.floor(d / 3600) + ' ساعة';
  return 'قبل ' + Math.floor(d / 86400) + ' يوم';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = (text == null) ? '' : String(text);
  return div.innerHTML
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\n/g, '<br>');
}

function escapeAttr(text) {
  return String((text == null) ? '' : text)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

function getUserIdentifier(user) {
  if (!user) return '';
  return user.accountNumber || user.phone || user.email || '';
}

async function requireAdmin() {
  const user = await API.me();
  if (!user || user.role !== 'admin') {
    toast('غير مصرح', 'error');
    return null;
  }
  return user;
}

/* ============================================================
   الساعة
   ============================================================ */
function updateClock() {
  const now = new Date();
  const clock = $('clock');
  if (clock) {
    clock.textContent =
      String(now.getHours()).padStart(2, '0') + ':' +
      String(now.getMinutes()).padStart(2, '0');
  }
}
updateClock();
setInterval(updateClock, 30000);

/* ============================================================
   طبقة API
   ============================================================ */
const API = {

  logout: async function() {
    await sb.auth.signOut();
  },

  me: async function() {
    const res = await sb.auth.getUser();
    const user = res.data.user;
    if (!user) return null;

    const q = await sb.from('profiles')
      .select('*').eq('id', user.id).single();
    const data = q.data;
    if (!data) return null;

    return {
      id: data.id,
      name: data.name,
      phone: data.phone,
      email: data.email,
      accountNumber: data.account_number,
      apiKey: data.api_key,
      role: data.role || 'customer',
      userType: data.user_type || 'regular',
      merchantStatus: data.merchant_status || 'approved',
      businessName: data.business_name,
      balance: Number(data.balance),
      balanceOmni: Number(data.balance_omni || 0),
      balanceUsd: Number(data.balance_usd || 0),
      balanceSyp: Number(data.balance_syp || 0),
      balanceEur: Number(data.balance_eur || 0),
    };
  },

  balance: async function() {
    const user = await this.me();
    if (!user) {
      return { balance: 0, balanceOmni: 0, balanceUsd: 0, balanceSyp: 0, balanceEur: 0 };
    }
    return {
      balance: user.balance,
      balanceOmni: user.balanceOmni,
      balanceUsd: user.balanceUsd,
      balanceSyp: user.balanceSyp,
      balanceEur: user.balanceEur,
    };
  },

  transactions: async function() {
    const res = await sb.auth.getUser();
    const user = res.data.user;
    if (!user) return { transactions: [] };

    const q = await sb.from('transactions')
      .select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(200);

    return {
      transactions: (q.data || []).map(function(t) {
        return {
          id: t.id,
          type: t.type,
          title: t.title,
          amount: Number(t.amount),
          date: new Date(t.created_at).getTime()
        };
      })
    };
  },

  transfer: async function(params) {
    showLoading();
    try {
      const { data, error } = await sb.rpc('transfer_funds', {
        p_to: params.to,
        p_amount: Number(params.amount),
        p_fee: TRANSFER_FEE_RATE
      });
      if (error) throw new Error(error.message);
      return data;
    } finally {
      hideLoading();
    }
  },

  exchange: async function(params) {
    showLoading();
    try {
      const { data, error } = await sb.rpc('exchange_currency', {
        p_from: params.from,
        p_to: params.to,
        p_amount: Number(params.amount)
      });
      if (error) throw new Error(error.message);
      return data;
    } finally {
      hideLoading();
    }
  },

  lookup: async function(identifier) {
    const { data, error } = await sb.rpc('lookup_user', {
      p_identifier: identifier
    });
    if (error) return { found: false };
    return data;
  },
};

/* ============================================================
   بوابة الإدارة
   ============================================================ */
function openPortal() {
  if (typeof router !== 'undefined' && router && router.go) {
    router.go('screen-portal');
    if (navigator.vibrate) navigator.vibrate(30);
  } else {
    console.error('router غير متاح');
  }
}

function pickPortalRole(role) {
  if (role !== 'merchant' && role !== 'admin') return;

  if (typeof router === 'undefined' || !router) return;

  router.go('screen-auth');

  setTimeout(function() {
    if (typeof selectRole === 'function') selectRole(role);
    if (role === 'merchant') {
      toast('بوابة التاجر', 'success');
    } else {
      toast('بوابة الإدارة', 'success');
    }
  }, 150);
}

function showAdminRole() {
  openPortal();
}

function handleLogoClick() {
  adminAccessCounter++;
  clearTimeout(adminAccessTimer);
  adminAccessTimer = setTimeout(function() { adminAccessCounter = 0; }, 3000);

  if (adminAccessCounter >= 5) {
    adminAccessCounter = 0;
    clearTimeout(adminAccessTimer);
    openPortal();
  }

  if (adminAccessCounter >= 3) {
    const logo = document.querySelector('.login-logo');
    if (logo) {
      logo.style.transform = 'scale(1.08)';
      logo.style.transition = 'transform 0.15s';
      setTimeout(function() { logo.style.transform = 'scale(1)'; }, 150);
    }
  }
}

/* إضافة animation fadeIn */
if (!document.getElementById('amanFadeIn')) {
  const style = document.createElement('style');
  style.id = 'amanFadeIn';
  style.textContent = '@keyframes fadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }';
  document.head.appendChild(style);
}

/* ============================================================
   🔌 مؤشر حالة الاتصال بقاعدة البيانات (نسخة محمية بالكامل)
   ============================================================ */

var dbStatusChannel = null;
var dbReconnectTimer = null;
var dbPingTimer = null;
var dbLastPing = 0;
var dbLatency = 0;

function setDbStatus(status) {
  try {
    const el = document.getElementById('dbStatus');
    if (!el) return;

    el.classList.remove('connected', 'connecting', 'disconnected');
    el.classList.add(status);

    const icon = el.querySelector('i');
    if (icon) icon.className = 'fas fa-circle';

    if (status === 'connected') {
      el.title = 'متصل بقاعدة البيانات' + (dbLatency ? ' — ' + dbLatency + 'ms' : '');
    } else if (status === 'connecting') {
      el.title = 'جاري الاتصال...';
    } else {
      el.title = 'غير متصل — سيُعاد المحاولة تلقائياً';
    }
  } catch (e) {
    console.warn('setDbStatus error:', e);
  }
}

async function pingSupabase() {
  try {
    const start = Date.now();
    const result = await sb.from('profiles').select('id').limit(1);
    dbLatency = Date.now() - start;
    dbLastPing = Date.now();

    if (result.error) throw result.error;
    setDbStatus('connected');
    return true;
  } catch (e) {
    console.warn('ping failed:', e.message);
    setDbStatus('disconnected');
    return false;
  }
}

function startDbMonitor() {
  try {
    setDbStatus('connecting');
    pingSupabase();

    window.addEventListener('online', function() {
      setDbStatus('connecting');
      setTimeout(pingSupabase, 500);
    });

    window.addEventListener('offline', function() {
      setDbStatus('disconnected');
    });

    if (dbPingTimer) clearInterval(dbPingTimer);
    dbPingTimer = setInterval(function() {
      if (navigator.onLine) {
        pingSupabase();
      } else {
        setDbStatus('disconnected');
      }
    }, 20000);

    document.addEventListener('visibilitychange', function() {
      if (!document.hidden && navigator.onLine) {
        pingSupabase();
      }
    });

    /* Realtime channel — نسخة محمية */
    try {
      if (dbStatusChannel && sb.removeChannel) {
        sb.removeChannel(dbStatusChannel);
      }

      dbStatusChannel = sb.channel('db-status-monitor');

      const subscribeResult = dbStatusChannel.subscribe(function(status) {
        if (status === 'SUBSCRIBED') {
          setDbStatus('connected');
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          setDbStatus('disconnected');
          if (dbReconnectTimer) clearTimeout(dbReconnectTimer);
          dbReconnectTimer = setTimeout(startDbMonitor, 5000);
        }
      });

      if (subscribeResult && typeof subscribeResult.catch === 'function') {
        subscribeResult.catch(function(e) {
          console.warn('Realtime subscribe failed:', e);
        });
      }
    } catch (e) {
      console.warn('Realtime channel setup failed:', e);
    }
  } catch (e) {
    console.error('startDbMonitor failed:', e);
  }
}

/* بدء المراقبة */
try {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      try { startDbMonitor(); } catch (e) { console.warn('db monitor init error:', e); }
    });
  } else {
    startDbMonitor();
  }
} catch (e) {
  console.error('db monitor global error:', e);
}

window.setDbStatus = setDbStatus;
window.pingSupabase = pingSupabase;