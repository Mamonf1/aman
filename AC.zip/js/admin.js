/* ============================================================
   أمان كاش — 4-admin.js
   لوحة الإدارة (7 تبويبات) + القروض + الدردشة + الخزينة
   ============================================================ */

/* ============================================================
   لوحة الإدارة الرئيسية (7 تبويبات)
   ============================================================ */
async function renderAdminDash() {
  currentUser = await API.me();
  if (!currentUser || currentUser.role !== 'admin') return router.go('screen-auth');

  try {
    const { data, error } = await sb.rpc('admin_stats');
    if (error) throw error;
    if (data) {
      $('aTotalUsers').textContent = data.total_users || 0;
      $('aTotalMerchants').textContent = data.total_merchants || 0;
      $('aTotalTx').textContent = data.total_transactions || 0;
    }
  } catch (e) {
    console.warn('admin_stats فشلت:', e.message);
  }

  const content = $('adminContent');
  content.innerHTML = `
    <div style="position:sticky;top:0;z-index:100;background:#f1f5f9;padding:8px 0 12px;margin:0 -16px;padding-inline:16px">
      <button onclick="exitAdminSection()" style="width:100%;background:#fff;border:1.5px solid #e2e8f0;padding:10px;border-radius:12px;font-family:'Cairo';font-weight:700;font-size:13px;color:#0F172A;cursor:pointer;margin-bottom:8px;display:flex;align-items:center;justify-content:center;gap:8px">
        <i class="fas fa-arrow-right"></i> رجوع للرئيسية
      </button>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;background:#fff;padding:4px;border-radius:12px;border:1px solid #e2e8f0">
        <div class="admin-tab active" data-tab="overview" onclick="switchAdminTab('overview')" style="background:#0F172A;color:#c4b5fd;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">نظرة</div>
        <div class="admin-tab" data-tab="users" onclick="switchAdminTab('users')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">عملاء</div>
        <div class="admin-tab" data-tab="merchants" onclick="switchAdminTab('merchants')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">تجار</div>
        <div class="admin-tab" data-tab="loans" onclick="switchAdminTab('loans')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">💰 قروض</div>
        <div class="admin-tab" data-tab="shares" onclick="switchAdminTab('shares')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">📈 أسهم</div>
        <div class="admin-tab" data-tab="treasury" onclick="switchAdminTab('treasury')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">🏦 خزينة</div>
        <div class="admin-tab" data-tab="chats" onclick="switchAdminTab('chats')" style="color:#64748b;padding:8px 2px;font-size:10px;border-radius:10px;text-align:center;font-weight:700;cursor:pointer">دردشة</div>
      </div>
    </div>

    <div id="adminTab-overview" class="admin-tab-content">
      <div class="card">
        <div class="card-title"><i class="fas fa-chart-line"></i> إحصائيات</div>
        <div class="stats-grid" style="margin:0">
          <div class="stat-card"><div class="ico">💰</div><div class="lbl">الحجم الكلي</div><div class="val" id="aVolume">0</div></div>
          <div class="stat-card"><div class="ico">📦</div><div class="lbl">المنتجات</div><div class="val" id="aProducts">0</div></div>
        </div>
      </div>
    </div>

    <div id="adminTab-users" class="admin-tab-content" style="display:none">
      <div class="card">
        <div class="card-title"><i class="fas fa-users"></i> كل العملاء
          <button onclick="loadAllUsers()" style="margin-right:auto;background:transparent;border:none;color:#2563eb;font-family:'Cairo';font-weight:700;font-size:12px;cursor:pointer">
            <i class="fas fa-sync-alt"></i> تحديث
          </button>
        </div>
        <div id="allUsersList"><div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div></div>
      </div>
    </div>

    <div id="adminTab-merchants" class="admin-tab-content" style="display:none">
      <div class="card">
        <div class="card-title"><i class="fas fa-hourglass-half"></i> قيد المراجعة</div>
        <div id="pendingMerchantsList">جاري التحميل...</div>
      </div>
      <div class="card">
        <div class="card-title"><i class="fas fa-check-circle"></i> المعتمدون</div>
        <div id="approvedMerchantsList">جاري التحميل...</div>
      </div>
    </div>

    <div id="adminTab-loans" class="admin-tab-content" style="display:none">
      <div class="card" style="background:linear-gradient(135deg,#FEF3C7,#FDE68A);border:2px solid #D97706">
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:12px">
          <div style="background:#fff;padding:12px;border-radius:12px;text-align:center">
            <div style="font-size:10px;color:#64748b;font-weight:700;margin-bottom:4px">إجمالي المُقرَض</div>
            <div style="font-size:16px;font-weight:800;color:#B45309" id="loansTotalLent">0</div>
          </div>
          <div style="background:#fff;padding:12px;border-radius:12px;text-align:center">
            <div style="font-size:10px;color:#64748b;font-weight:700;margin-bottom:4px">المتبقي</div>
            <div style="font-size:16px;font-weight:800;color:#dc2626" id="loansOutstanding">0</div>
          </div>
          <div style="background:#fff;padding:12px;border-radius:12px;text-align:center">
            <div style="font-size:10px;color:#64748b;font-weight:700;margin-bottom:4px">نشطة</div>
            <div style="font-size:16px;font-weight:800;color:#16a34a" id="loansActive">0</div>
          </div>
          <div style="background:#fff;padding:12px;border-radius:12px;text-align:center">
            <div style="font-size:10px;color:#64748b;font-weight:700;margin-bottom:4px">مُسَدَّدة</div>
            <div style="font-size:16px;font-weight:800;color:#0F172A" id="loansPaid">0</div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button onclick="openGrantBalance()" style="background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;padding:12px;font-size:13px;border-radius:10px;border:none;font-weight:800;cursor:pointer;font-family:'Cairo'">
            <i class="fas fa-gift"></i> منح رصيد
          </button>
          <button onclick="openCreateLoan()" style="background:linear-gradient(135deg,#D97706,#B45309);color:#fff;padding:12px;font-size:13px;border-radius:10px;border:none;font-weight:800;cursor:pointer;font-family:'Cairo'">
            <i class="fas fa-hand-holding-usd"></i> إنشاء قرض
          </button>
        </div>
      </div>
      <div class="card">
        <div class="card-title"><i class="fas fa-list"></i> كل القروض
          <button onclick="loadLoans()" style="margin-right:auto;background:transparent;border:none;color:#D97706;font-family:'Cairo';font-weight:700;font-size:12px;cursor:pointer">
            <i class="fas fa-sync-alt"></i> تحديث
          </button>
        </div>
        <div id="loansList"><div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div></div>
      </div>
    </div>

    <div id="adminTab-shares" class="admin-tab-content" style="display:none">
      <div class="card" style="background:linear-gradient(135deg,#0F172A,#1E293B);border:none;color:#fff">
        <div style="font-size:14px;font-weight:800;margin-bottom:8px">📈 إدارة إصدارات الأسهم</div>
        <div style="font-size:11.5px;color:#94a3b8;line-height:1.7;margin-bottom:14px">
          أنشئ إصداراً جديداً → يكتتب المستخدمون → افتح التداول → بيع وشراء بين المستخدمين
        </div>
        <button onclick="openCreateOffering()" style="width:100%;background:linear-gradient(135deg,#D97706,#B45309);color:#fff;padding:13px;border-radius:12px;border:none;font-family:'Cairo';font-weight:800;font-size:13px;cursor:pointer">
          <i class="fas fa-plus-circle"></i> إنشاء إصدار جديد
        </button>
      </div>
      <div class="card">
        <div class="card-title"><i class="fas fa-list"></i> كل الإصدارات
          <button onclick="loadAdminShares()" style="margin-right:auto;background:transparent;border:none;color:#D97706;font-family:'Cairo';font-weight:700;font-size:12px;cursor:pointer">
            <i class="fas fa-sync-alt"></i> تحديث
          </button>
        </div>
        <div id="adminSharesList"><div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div></div>
      </div>
    </div>

    <div id="adminTab-treasury" class="admin-tab-content" style="display:none">
      <div class="card" style="background:linear-gradient(135deg,#FCD34D,#F59E0B,#D97706);color:#fff;border:none">
        <div style="font-size:16px;font-weight:800;margin-bottom:4px">🏦 خزينة النظام</div>
        <div style="font-size:11.5px;color:rgba(255,255,255,.9);margin-bottom:14px">
          الأرباح المجمعة من العمولات والأسهم
        </div>
        <div id="treasuryBalances"></div>
      </div>

      <div class="card">
        <div class="card-title"><i class="fas fa-chart-pie"></i> الأرباح حسب المصدر</div>
        <div id="treasuryBySource"></div>
      </div>

      <div class="card">
        <div class="card-title">
          <i class="fas fa-history"></i> آخر الحركات
          <button onclick="loadTreasury()" style="margin-right:auto;background:transparent;border:none;color:#D97706;font-family:'Cairo';font-weight:700;font-size:12px;cursor:pointer">
            <i class="fas fa-sync-alt"></i> تحديث
          </button>
        </div>
        <div id="treasuryTransactions"></div>
      </div>
    </div>

    <div id="adminTab-chats" class="admin-tab-content" style="display:none">
      <div class="card">
        <div class="card-title"><i class="fas fa-comments"></i> كل المحادثات</div>
        <div id="adminChatListTab"><div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div></div>
      </div>
    </div>
  `;

  loadPendingMerchants();
  loadApprovedMerchants();
  loadAllUsers();
  loadAdminConversationsForTab();
  loadLoansData();
  loadAdminShares();
  loadTreasury();
}

/* تبديل التبويبات */
function switchAdminTab(tab) {
  const content = $('adminContent');
  if (content) content.scrollTop = 0;

  document.querySelectorAll('.admin-tab').forEach(function(t) {
    const isActive = t.dataset.tab === tab;
    t.style.background = isActive ? '#0F172A' : 'transparent';
    t.style.color = isActive ? '#c4b5fd' : '#64748b';
  });

  document.querySelectorAll('.admin-tab-content').forEach(function(c) {
    c.style.display = 'none';
  });

  const target = $('adminTab-' + tab);
  if (target) target.style.display = 'block';

  if (tab === 'chats') loadAdminConversationsForTab();
  if (tab === 'users') loadAllUsers();
  if (tab === 'merchants') { loadPendingMerchants(); loadApprovedMerchants(); }
  if (tab === 'loans') { loadLoans(); loadLoansStats(); }
  if (tab === 'shares') loadAdminShares();
  if (tab === 'treasury') loadTreasury();
}

/* الخروج من قسم الإدارة */
function exitAdminSection() {
  document.querySelectorAll('.qr-modal.show').forEach(function(m) { m.classList.remove('show'); });
  document.body.classList.remove('modal-open');
  if (typeof cleanupNfc === 'function') cleanupNfc();
  router.go('screen-home');
  toast('تم الخروج من قسم الإدارة');
}

/* ============================================================
   العملاء
   ============================================================ */
async function loadAllUsers() {
  const list = $('allUsersList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_all_users', { p_limit: 200 });
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">📭 لا يوجد عملاء</div>';
      return;
    }

    list.innerHTML = data.map(function(u) {
      const isVip = u.user_type === 'vip';
      const isMerchant = u.role === 'merchant';
      const isPending = u.merchant_status === 'pending';
      const initial = (u.name || '?').charAt(0);

      let badge = '';
      if (isMerchant && isPending) badge = '<span style="background:#fef3c7;color:#92400e;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:700">⏳ قيد المراجعة</span>';
      else if (isMerchant) badge = '<span style="background:#dcfce7;color:#166534;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:700">🏪 تاجر</span>';
      else badge = '<span style="background:#e0e7ff;color:#3730a3;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:700">👤 عميل</span>';

      if (isVip) badge += ' <span style="background:linear-gradient(135deg,#FCD34D,#D97706);color:#fff;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:700">⭐ VIP</span>';

      return `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin-bottom:8px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#D97706,#B45309);color:#fff;display:flex;justify-content:center;align-items:center;font-weight:800;font-size:15px;flex-shrink:0">${escapeHtml(initial)}</div>
            <div style="flex:1;min-width:0">
              <div style="font-size:13.5px;font-weight:800;color:#0F172A;margin-bottom:2px">${escapeHtml(u.name || 'مستخدم')}</div>
              <div style="font-size:11px;color:#64748b;direction:ltr;text-align:right">${escapeHtml(u.email || '')}</div>
            </div>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">${badge}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px">
            <div style="background:#fff;padding:6px;border-radius:8px;border:1px solid #e2e8f0">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">رقم الحساب</div>
              <div style="font-weight:800;color:#0F172A;direction:ltr;text-align:right">${escapeHtml(u.account_number || '—')}</div>
            </div>
            <div style="background:#fff;padding:6px;border-radius:8px;border:1px solid #e2e8f0">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">الرصيد (OMNI)</div>
              <div style="font-weight:800;color:#D97706">${formatNumber(u.balance_omni || u.balance || 0, 2)}</div>
            </div>
          </div>
          <div style="margin-top:8px;display:flex;gap:6px">
            <button data-action="toggle-vip" data-user-id="${escapeAttr(u.id)}" data-user-type="${escapeAttr(u.user_type || '')}" style="flex:1;background:${isVip ? '#f1f5f9' : 'linear-gradient(135deg,#D97706,#B45309)'};color:${isVip ? '#64748b' : '#fff'};border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:800;font-size:11px;cursor:pointer">
              <i class="fas fa-star"></i> ${isVip ? 'إلغاء VIP' : 'ترقية VIP'}
            </button>
            <button data-action="grant" data-user-id="${escapeAttr(u.id)}" style="background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;border:none;padding:8px 12px;border-radius:8px;cursor:pointer" title="منح رصيد">
              <i class="fas fa-gift"></i>
            </button>
            <button data-action="copy" data-account="${escapeAttr(u.account_number || '')}" data-phone="${escapeAttr(u.phone || '')}" style="background:#f1f5f9;color:#64748b;border:none;padding:8px 12px;border-radius:8px;cursor:pointer" title="نسخ">
              <i class="fas fa-copy"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('button[data-action]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const action = btn.dataset.action;
        if (action === 'toggle-vip') toggleUserVip(btn.dataset.userId, btn.dataset.userType);
        if (action === 'grant') openGrantBalance(btn.dataset.userId);
        if (action === 'copy') copyUserInfo(btn.dataset.account, btn.dataset.phone);
      });
    });

  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function toggleUserVip(userId, currentType) {
  if (!await requireAdmin()) return;
  showLoading();
  try {
    const fn = currentType === 'vip' ? 'downgrade_from_vip' : 'upgrade_to_vip';
    const { error } = await sb.rpc(fn, { p_id: userId });
    if (error) throw error;
    toast(currentType === 'vip' ? 'تم إلغاء VIP' : '⭐ تم الترقية', 'success');
    await loadAllUsers();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

function copyUserInfo(accountNumber, phone) {
  const text = 'رقم الحساب: ' + accountNumber + (phone ? ' | الهاتف: ' + phone : '');
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(
      function() { toast('تم النسخ ✅', 'success'); },
      function() { toast('تعذر النسخ', 'error'); }
    );
  }
}

/* ============================================================
   التجار
   ============================================================ */
async function loadPendingMerchants() {
  try {
    const { data } = await sb.rpc('get_pending_merchants');
    const list = $('pendingMerchantsList');
    if (!list) return;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:20px;color:#94a3b8;font-size:13px">✅ لا طلبات معلقة</div>';
      return;
    }

    list.innerHTML = data.map(function(m) {
      return `
        <div class="card" style="padding:12px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
            <div class="conv-avatar" style="background:linear-gradient(135deg,#16a34a,#15803d)">${escapeHtml((m.business_name || m.name || '?').charAt(0))}</div>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:800">${escapeHtml(m.business_name || 'بدون اسم')}</div>
              <div style="font-size:11px;color:#64748b">${escapeHtml(m.name)} · ${escapeHtml(m.phone)}</div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <button data-action="approve" data-id="${escapeAttr(m.id)}" class="btn btn-green" style="padding:8px;font-size:12px"><i class="fas fa-check"></i> قبول</button>
            <button data-action="reject" data-id="${escapeAttr(m.id)}" class="btn" style="background:#dc2626;color:#fff;padding:8px;font-size:12px"><i class="fas fa-times"></i> رفض</button>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('button[data-action]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        if (btn.dataset.action === 'approve') approveMerchant(btn.dataset.id);
        if (btn.dataset.action === 'reject') rejectMerchant(btn.dataset.id);
      });
    });
  } catch (e) {
    console.error('loadPendingMerchants:', e);
  }
}

async function loadApprovedMerchants() {
  const list = $('approvedMerchantsList');
  if (!list) return;
  try {
    const { data, error } = await sb.from('profiles')
      .select('id, name, business_name, phone, balance, user_type')
      .eq('role', 'merchant').eq('merchant_status', 'approved')
      .order('created_at', { ascending: false }).limit(30);
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:20px;color:#94a3b8;font-size:13px">لا يوجد تجار</div>';
      return;
    }

    list.innerHTML = data.map(function(m) {
      return `
        <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f1f5f9">
          <div class="conv-avatar" style="background:linear-gradient(135deg,#16a34a,#15803d)">${escapeHtml((m.business_name || m.name || '?').charAt(0))}</div>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:800">${escapeHtml(m.business_name || m.name)} ${m.user_type === 'vip' ? '⭐' : ''}</div>
            <div style="font-size:11px;color:#64748b">${escapeHtml(m.phone)} · ${formatNumber(m.balance, 0)} OMNI</div>
          </div>
        </div>
      `;
    }).join('');
  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function approveMerchant(id) {
  if (!await requireAdmin()) return;
  showLoading();
  try {
    const { error } = await sb.rpc('approve_merchant', { p_id: id });
    if (error) throw error;
    toast('✅ تم القبول', 'success');
    loadPendingMerchants();
    loadApprovedMerchants();
    loadAllUsers();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function rejectMerchant(id) {
  if (!await requireAdmin()) return;
  const reason = prompt('سبب الرفض:');
  if (reason === null) return;
  showLoading();
  try {
    const { error } = await sb.rpc('reject_merchant', { p_id: id, p_reason: reason || null });
    if (error) throw error;
    toast('تم الرفض', 'success');
    loadPendingMerchants();
    loadAllUsers();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   القروض الإدارية
   ============================================================ */
async function loadLoansStats() {
  try {
    const { data, error } = await sb.rpc('admin_loans_stats');
    if (error) throw error;
    if (data) {
      const totalEl = $('loansTotalLent');
      const outEl = $('loansOutstanding');
      const actEl = $('loansActive');
      const paidEl = $('loansPaid');
      if (totalEl) totalEl.textContent = formatNumber(data.total_lent, 0);
      if (outEl) outEl.textContent = formatNumber(data.total_outstanding, 0);
      if (actEl) actEl.textContent = data.active_loans || 0;
      if (paidEl) paidEl.textContent = data.paid_loans || 0;
    }
  } catch (e) {
    console.error('loadLoansStats:', e);
  }
}

async function loadLoans() {
  const list = $('loansList');
  if (!list) return;
  list.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('admin_get_loans');
    if (error) throw error;

    if (!data || !data.length) {
      list.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">📭 لا توجد قروض</div>';
      return;
    }

    list.innerHTML = data.map(function(l) {
      const statusMap = {
        'active':    { color: '#dcfce7', text: '#166534', label: '🟢 نشط' },
        'paid':      { color: '#dbeafe', text: '#1e40af', label: '✅ مسدد' },
        'defaulted': { color: '#fee2e2', text: '#991b1b', label: '❌ متعثر' },
        'cancelled': { color: '#f1f5f9', text: '#64748b', label: '🚫 ملغي' }
      };
      const s = statusMap[l.status] || statusMap['active'];

      return `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:8px">
            <div>
              <div style="font-size:13px;font-weight:800;color:#0F172A">${escapeHtml(l.user_name)}</div>
              <div style="font-size:10.5px;color:#64748b;direction:ltr;text-align:left">${escapeHtml(l.user_account)}</div>
            </div>
            <span style="background:${s.color};color:${s.text};padding:3px 8px;border-radius:8px;font-size:10px;font-weight:700;white-space:nowrap">${s.label}</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:8px;font-size:11px">
            <div style="background:#fff;padding:6px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">القرض</div>
              <div style="font-weight:800;color:#0F172A">${formatNumber(l.amount, 0)}</div>
            </div>
            <div style="background:#fff;padding:6px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">المدفوع</div>
              <div style="font-weight:800;color:#16a34a">${formatNumber(l.paid_amount, 0)}</div>
            </div>
            <div style="background:#fff;padding:6px;border-radius:8px;border:1px solid #e2e8f0;text-align:center">
              <div style="color:#94a3b8;font-size:9.5px;margin-bottom:2px">المتبقي</div>
              <div style="font-weight:800;color:#dc2626">${formatNumber(l.remaining, 0)}</div>
            </div>
          </div>
          ${l.notes ? '<div style="font-size:10.5px;color:#64748b;margin-bottom:6px">📝 ' + escapeHtml(l.notes) + '</div>' : ''}
          ${l.status === 'active' ? `
            <div style="display:grid;grid-template-columns:2fr 1fr;gap:6px">
              <button data-action="pay" data-id="${l.id}" style="background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">
                <i class="fas fa-money-bill-wave"></i> دفع قسط
              </button>
              <button data-action="cancel" data-id="${l.id}" style="background:#fee2e2;color:#dc2626;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">
                <i class="fas fa-times"></i> إلغاء
              </button>
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    list.querySelectorAll('button[data-action]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const id = Number(btn.dataset.id);
        if (btn.dataset.action === 'pay') payLoan(id);
        if (btn.dataset.action === 'cancel') cancelLoan(id);
      });
    });
  } catch (e) {
    list.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function loadLoansData() {
  await loadLoans();
  await loadLoansStats();
}

async function openGrantBalance(userId) {
  if (!await requireAdmin()) return;
  userId = userId || null;
  let modal = $('grantBalanceModal');

  if (!modal) {
    const html = `
      <div class="qr-modal" id="grantBalanceModal">
        <div class="qr-modal-box">
          <button type="button" class="qr-close" onclick="closeGrantBalance()"><i class="fas fa-times"></i></button>
          <h3>🎁 منح رصيد</h3>
          <div class="field"><label>المستخدم</label><select id="grantUser"></select></div>
          <div class="field"><label>المبلغ</label><input type="number" id="grantAmount" value="1000000" min="1"></div>
          <div class="field">
            <label>العملة</label>
            <select id="grantCurrency">
              <option value="OMNI">💠 OMNI — أومني</option>
              <option value="USD">$ دولار أمريكي</option>
              <option value="SYP">ل.س ليرة سورية</option>
              <option value="EUR">€ يورو</option>
            </select>
          </div>
          <div class="field"><label>ملاحظة (اختياري)</label><input id="grantNote" placeholder="رصيد تجريبي"></div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:12px">
            <button type="button" data-preset="1000000" class="btn-preset" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">1 مليون</button>
            <button type="button" data-preset="100000" class="btn-preset" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">100 ألف</button>
            <button type="button" data-preset="10000" class="btn-preset" style="background:#f1f5f9;border:none;padding:8px;border-radius:8px;font-family:'Cairo';font-weight:700;font-size:11px;cursor:pointer">10 آلاف</button>
          </div>
          <button type="button" class="btn btn-gold" onclick="submitGrantBalance()"><i class="fas fa-check"></i> تأكيد المنح</button>
          <button type="button" class="btn btn-outline" onclick="closeGrantBalance()"><i class="fas fa-times"></i> إلغاء</button>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    modal = $('grantBalanceModal');
    modal.addEventListener('click', function(e) { if (e.target === modal) closeGrantBalance(); });
    modal.querySelectorAll('.btn-preset').forEach(function(b) {
      b.addEventListener('click', function() { $('grantAmount').value = b.dataset.preset; });
    });
  }

  modal.classList.add('show');
  document.body.classList.add('modal-open');

  const escHandler = function(e) {
    if (e.key === 'Escape') {
      closeGrantBalance();
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);

  await fillUserSelect('grantUser', userId);
}

function closeGrantBalance() {
  const m = $('grantBalanceModal');
  if (m) m.classList.remove('show');
  document.body.classList.remove('modal-open');
}

async function fillUserSelect(selectId, preselectedId) {
  preselectedId = preselectedId || null;
  try {
    const { data, error } = await sb.rpc('get_all_users', { p_limit: 500 });
    if (error) throw error;
    const select = $(selectId);
    if (!select) return;

    if (!data || !data.length) {
      select.innerHTML = '<option value="">لا يوجد مستخدمون</option>';
      return;
    }

    select.innerHTML = '<option value="">اختر المستخدم...</option>' +
      data.map(function(u) {
        return '<option value="' + escapeAttr(u.id) + '"' + (u.id === preselectedId ? ' selected' : '') + '>' + escapeHtml(u.name) + ' — ' + escapeHtml(u.account_number) + '</option>';
      }).join('');
  } catch (e) {
    console.error('fillUserSelect:', e);
    toast('فشل تحميل المستخدمين', 'error');
  }
}

async function submitGrantBalance() {
  if (!await requireAdmin()) return;
  const userId = $('grantUser').value;
  const amount = Number($('grantAmount').value);
  const currency = $('grantCurrency').value;
  const note = $('grantNote').value.trim();

  if (!userId) return toast('اختر المستخدم', 'error');
  if (!amount || amount <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');

  showLoading();
  try {
    const { data, error } = await sb.rpc('admin_grant_balance', {
      p_user_id: userId,
      p_amount: amount,
      p_currency: currency,
      p_note: note || null
    });
    if (error) throw error;

    toast('✅ تم منح ' + formatNumber(amount) + ' ' + currency + ' إلى ' + data.user_name, 'success');
    closeGrantBalance();
    await loadAllUsers();
    await loadLoansStats();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function openCreateLoan() {
  if (!await requireAdmin()) return;
  let modal = $('createLoanModal');

  if (!modal) {
    const html = `
      <div class="qr-modal" id="createLoanModal">
        <div class="qr-modal-box">
          <button type="button" class="qr-close" onclick="closeCreateLoan()"><i class="fas fa-times"></i></button>
          <h3>💰 إنشاء قرض</h3>
          <div class="field"><label>المستخدم</label><select id="loanUser"></select></div>
          <div class="field"><label>مبلغ القرض (OMNI)</label><input type="number" id="loanAmount" value="1000000" min="1"></div>
          <div class="field"><label>نسبة الفائدة % (اختياري)</label><input type="number" id="loanInterest" value="0" min="0" max="100"></div>
          <div class="field"><label>تاريخ الاستحقاق (اختياري)</label><input type="date" id="loanDueDate"></div>
          <div class="field"><label>ملاحظات</label><input id="loanNotes" placeholder="قرض شخصي"></div>
          <button type="button" class="btn btn-gold" onclick="submitCreateLoan()"><i class="fas fa-check"></i> إنشاء القرض</button>
          <button type="button" class="btn btn-outline" onclick="closeCreateLoan()"><i class="fas fa-times"></i> إلغاء</button>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
    modal = $('createLoanModal');
    modal.addEventListener('click', function(e) { if (e.target === modal) closeCreateLoan(); });
  }

  modal.classList.add('show');
  document.body.classList.add('modal-open');

  const escHandler = function(e) {
    if (e.key === 'Escape') {
      closeCreateLoan();
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);

  await fillUserSelect('loanUser');
}

function closeCreateLoan() {
  const m = $('createLoanModal');
  if (m) m.classList.remove('show');
  document.body.classList.remove('modal-open');
}

async function submitCreateLoan() {
  if (!await requireAdmin()) return;
  const userId = $('loanUser').value;
  const amount = Number($('loanAmount').value);
  const interest = Number($('loanInterest').value) || 0;
  const dueDate = $('loanDueDate').value;
  const notes = $('loanNotes').value.trim();

  if (!userId) return toast('اختر المستخدم', 'error');
  if (!amount || amount <= 0) return toast('أدخل مبلغاً صحيحاً', 'error');

  showLoading();
  try {
    const { data, error } = await sb.rpc('admin_create_loan', {
      p_user_id: userId,
      p_amount: amount,
      p_interest_rate: interest,
      p_due_date: dueDate ? new Date(dueDate).toISOString() : null,
      p_notes: notes || null
    });
    if (error) throw error;

    toast('✅ تم إنشاء قرض ' + formatNumber(amount) + ' OMNI لـ ' + data.user_name, 'success');
    closeCreateLoan();
    await loadLoans();
    await loadLoansStats();
    await loadAllUsers();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function payLoan(loanId) {
  if (!await requireAdmin()) return;
  const amount = prompt('مبلغ القسط:');
  if (!amount || Number(amount) <= 0) return;
  const note = prompt('ملاحظة (اختياري):') || null;

  showLoading();
  try {
    const { data, error } = await sb.rpc('admin_pay_loan', {
      p_loan_id: loanId,
      p_amount: Number(amount),
      p_note: note
    });
    if (error) throw error;
    toast('✅ تم دفع ' + formatNumber(amount) + ' — المتبقي: ' + formatNumber(data.remaining, 0), 'success');
    await loadLoans();
    await loadLoansStats();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

async function cancelLoan(loanId) {
  if (!await requireAdmin()) return;
  if (!confirm('هل تريد إلغاء القرض؟')) return;
  showLoading();
  try {
    const { error } = await sb.rpc('admin_cancel_loan', { p_loan_id: loanId });
    if (error) throw error;
    toast('تم إلغاء القرض', 'success');
    await loadLoans();
    await loadLoansStats();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    hideLoading();
  }
}

/* ============================================================
   الدردشة (العميل)
   ============================================================ */
async function renderChat() {
  currentUser = currentUser || await API.me();
  if (!currentUser) return router.go('screen-auth');

  const el = $('chatMessages');
  el.innerHTML = '<div style="text-align:center;color:#94a3b8;font-size:13px;padding:20px">جاري التحميل...</div>';

  try {
    const { data: convData, error } = await sb.rpc('get_or_create_conversation');
    if (error) throw error;
    currentConversationId = convData.conversation_id;
    await loadChatMessages();
  } catch (e) {
    el.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:13px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function loadChatMessages() {
  const el = $('chatMessages');
  try {
    const { data, error } = await sb.rpc('get_messages', { p_conversation_id: currentConversationId });
    if (error) throw error;
    const msgs = data.messages || [];

    if (!msgs.length) {
      el.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#94a3b8"><i class="fas fa-comments" style="font-size:48px;color:#cbd5e1;margin-bottom:14px;display:block"></i><div style="font-size:14px;font-weight:700;color:#64748b;margin-bottom:6px">أهلاً بك 👋</div><div style="font-size:12px;line-height:1.7">ابدأ محادثة مع فريق الدعم</div></div>';
      return;
    }

    el.innerHTML = '';
    msgs.forEach(function(m) { appendMessage(m); });
    setTimeout(function() { el.scrollTop = el.scrollHeight; }, 100);
  } catch (e) {
    el.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

function appendMessage(msg) {
  const el = $('chatMessages');
  const isMine = msg.sender_role === 'user';
  const isAdmin = msg.sender_role === 'admin';
  el.insertAdjacentHTML('beforeend', '<div class="chat-message ' + (isMine ? 'mine' : '') + ' ' + (isAdmin ? 'admin' : '') + '"><div class="avatar">' + (isAdmin ? '👑' : escapeHtml((currentUser.name || 'أ').charAt(0))) + '</div><div style="flex:1;min-width:0"><div class="bubble">' + escapeHtml(msg.content) + '</div><div class="time">' + timeAgo(new Date(msg.created_at).getTime()) + '</div></div></div>');
}

async function sendChatMessage() {
  const input = $('chatInput');
  const content = input.value.trim();
  if (!content || !currentConversationId) return;
  input.value = '';
  input.style.height = 'auto';
  try {
    const { error } = await sb.rpc('send_message', {
      p_conversation_id: currentConversationId,
      p_content: content
    });
    if (error) throw error;
    await loadChatMessages();
  } catch (e) {
    toast(e.message, 'error');
  }
}

/* ============================================================
   الدردشة (الإدارة)
   ============================================================ */
async function loadAdminConversations() {
  const el = $('adminConversationsList');
  if (!el) return;
  el.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:40px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_all_conversations');
    if (error) throw error;

    if (!data || !data.length) {
      el.innerHTML = '<div style="text-align:center;padding:50px 20px;color:#94a3b8"><i class="fas fa-inbox" style="font-size:48px;color:#cbd5e1;margin-bottom:14px;display:block"></i>لا توجد محادثات</div>';
      return;
    }

    el.innerHTML = data.map(function(c) {
      return '<div class="conv-item ' + (c.unread_for_admin > 0 ? 'unread' : '') + '" data-conv-id="' + c.id + '" data-user-name="' + escapeAttr(c.user_name || 'مستخدم') + '" data-account="' + escapeAttr(c.account_number || '') + '"><div class="conv-header"><div class="conv-avatar">' + escapeHtml((c.user_name || '?').charAt(0)) + '</div><div class="conv-info"><div class="nm">' + escapeHtml(c.user_name || 'مستخدم') + '</div><div class="tm">' + timeAgo(new Date(c.last_message_at).getTime()) + '</div></div>' + (c.unread_for_admin > 0 ? '<div class="conv-badge">' + c.unread_for_admin + '</div>' : '') + '</div><div class="conv-preview">' + (c.last_message ? escapeHtml(c.last_message) : 'بدون رسائل') + '</div></div>';
    }).join('');

    el.querySelectorAll('.conv-item').forEach(function(item) {
      item.addEventListener('click', function() {
        openAdminChat(Number(item.dataset.convId), item.dataset.userName, item.dataset.account);
      });
    });
  } catch (e) {
    el.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

async function openAdminChat(convId, userName, accountNumber) {
  adminViewingConvId = convId;
  $('adminChatTitle').textContent = userName;
  $('adminChatSub').textContent = accountNumber || '—';
  router.go('screen-admin-chat-view');

  const el = $('adminChatMessages');
  el.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_messages', { p_conversation_id: convId });
    if (error) throw error;
    const msgs = data.messages || [];
    el.innerHTML = msgs.length ? '' : '<div style="text-align:center;color:#94a3b8;padding:20px;font-size:13px">لا توجد رسائل</div>';
    msgs.forEach(function(m) { appendAdminMessage(m); });
    setTimeout(function() { el.scrollTop = el.scrollHeight; }, 100);
  } catch (e) {
    el.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

function appendAdminMessage(msg) {
  const el = $('adminChatMessages');
  const isMine = msg.sender_role === 'admin';
  el.insertAdjacentHTML('beforeend', '<div class="chat-message ' + (isMine ? 'mine' : '') + ' ' + (msg.sender_role === 'admin' ? 'admin' : '') + '"><div class="avatar">' + (msg.sender_role === 'admin' ? '👑' : escapeHtml((msg.sender_name || '?').charAt(0))) + '</div><div style="flex:1;min-width:0"><div class="bubble">' + escapeHtml(msg.content) + '</div><div class="time">' + timeAgo(new Date(msg.created_at).getTime()) + '</div></div></div>');
}

async function sendAdminMessage() {
  const input = $('adminChatInput');
  const content = input.value.trim();
  if (!content || !adminViewingConvId) return;
  input.value = '';
  input.style.height = 'auto';

  try {
    const { error } = await sb.rpc('send_message', {
      p_conversation_id: adminViewingConvId,
      p_content: content
    });
    if (error) throw error;
    appendAdminMessage({
      content: content,
      sender_role: 'admin',
      created_at: new Date().toISOString(),
      sender_name: 'أنت'
    });
    const el = $('adminChatMessages');
    el.scrollTop = el.scrollHeight;
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function loadAdminConversationsForTab() {
  const el = $('adminChatListTab');
  if (!el) return;
  el.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px">جاري التحميل...</div>';

  try {
    const { data, error } = await sb.rpc('get_all_conversations');
    if (error) throw error;

    if (!data || !data.length) {
      el.innerHTML = '<div style="text-align:center;padding:30px;color:#94a3b8;font-size:13px">📭 لا توجد محادثات</div>';
      return;
    }

    el.innerHTML = data.map(function(c) {
      return '<div class="conv-item ' + (c.unread_for_admin > 0 ? 'unread' : '') + '" data-conv-id="' + c.id + '" data-user-name="' + escapeAttr(c.user_name || 'مستخدم') + '" data-account="' + escapeAttr(c.account_number || '') + '"><div class="conv-header"><div class="conv-avatar">' + escapeHtml((c.user_name || '?').charAt(0)) + '</div><div class="conv-info"><div class="nm">' + escapeHtml(c.user_name || 'مستخدم') + '</div><div class="tm">' + timeAgo(new Date(c.last_message_at).getTime()) + '</div></div>' + (c.unread_for_admin > 0 ? '<div class="conv-badge">' + c.unread_for_admin + '</div>' : '') + '</div><div class="conv-preview">' + (c.last_message ? escapeHtml(c.last_message) : 'بدون رسائل') + '</div></div>';
    }).join('');

    el.querySelectorAll('.conv-item').forEach(function(item) {
      item.addEventListener('click', function() {
        openAdminChat(Number(item.dataset.convId), item.dataset.userName, item.dataset.account);
      });
    });
  } catch (e) {
    el.innerHTML = '<div style="text-align:center;color:#dc2626;padding:20px;font-size:12px">❌ ' + escapeHtml(e.message) + '</div>';
  }
}

/* ============================================================
   🏦 الخزينة
   ============================================================ */
async function loadTreasury() {
  try {
    const { data: balances, error: errBal } = await sb.from('treasury').select('*');
    if (errBal) throw errBal;
    renderTreasuryBalances(balances || []);

    const { data: stats, error: errStats } = await sb.rpc('admin_treasury_stats');
    if (errStats) throw errStats;
    renderTreasuryStats(stats);

    const { data: txs, error: errTx } = await sb.rpc('admin_get_treasury_transactions', { p_limit: 30 });
    if (errTx) throw errTx;
    renderTreasuryTransactions(txs || []);

  } catch (e) {
    console.error('loadTreasury:', e);
    toast('فشل تحميل بيانات الخزينة', 'error');
  }
}

function renderTreasuryBalances(balances) {
  const el = $('treasuryBalances');
  if (!el) return;

  const icons = { OMNI: '💠', USD: '$', SYP: 'ل.س', EUR: '€' };

  el.innerHTML = balances.map(function(b) {
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.2)"><div style="display:flex;align-items:center;gap:8px"><span style="font-size:18px">' + (icons[b.currency] || '?') + '</span><span style="font-size:13px;font-weight:700">' + b.currency + '</span></div><div style="font-size:16px;font-weight:800">' + formatNumber(b.balance, 2) + '</div></div>';
  }).join('');
}

function renderTreasuryStats(stats) {
  const el = $('treasuryBySource');
  if (!el) return;

  const sourceLabels = {
    'transfer_fee': { icon: '🔄', label: 'عمولة تحويلات' },
    'exchange_fee': { icon: '💱', label: 'عمولة صرف' },
    'trade_fee':    { icon: '📈', label: 'عمولة تداول' },
    'dividend':     { icon: '💰', label: 'توزيعات أرباح' },
    'grant':        { icon: '🎁', label: 'منح' },
    'loan':         { icon: '🏦', label: 'قروض' },
    'manual':       { icon: '✍️', label: 'يدوي' }
  };

  if (!stats || !stats.by_source || !stats.by_source.length) {
    el.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px;font-size:12px">لا توجد بيانات بعد</div>';
    return;
  }

  el.innerHTML = stats.by_source.map(function(s) {
    const info = sourceLabels[s.source] || { icon: '•', label: s.source };
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #f1f5f9"><div style="display:flex;align-items:center;gap:8px"><span style="font-size:16px">' + info.icon + '</span><div><div style="font-size:12.5px;font-weight:700;color:#0F172A">' + info.label + '</div><div style="font-size:10px;color:#94a3b8">' + s.count + ' عملية</div></div></div><div style="font-size:14px;font-weight:800;color:#D97706">' + formatNumber(s.total, 2) + '</div></div>';
  }).join('');
}

function renderTreasuryTransactions(txs) {
  const el = $('treasuryTransactions');
  if (!el) return;

  if (!txs.length) {
    el.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:20px;font-size:12px">لا توجد حركات بعد</div>';
    return;
  }

  const sourceLabels = {
    'transfer_fee': '🔄',
    'exchange_fee': '💱',
    'trade_fee':    '📈',
    'dividend':     '💰',
    'grant':        '🎁',
    'loan':         '🏦',
    'manual':       '✍️'
  };

  el.innerHTML = txs.map(function(t) {
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #f1f5f9"><div style="flex:1;min-width:0"><div style="font-size:12px;font-weight:700;color:#0F172A;display:flex;align-items:center;gap:6px"><span>' + (sourceLabels[t.source] || '•') + '</span><span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px">' + escapeHtml(t.note || t.source) + '</span></div><div style="font-size:10px;color:#94a3b8;margin-top:2px">' + (t.user_name || 'النظام') + ' · ' + timeAgo(new Date(t.created_at).getTime()) + '</div></div><div style="font-weight:800;color:' + (t.type === 'in' ? '#16a34a' : '#dc2626') + ';font-size:13px;direction:ltr;white-space:nowrap;margin-right:8px">' + (t.type === 'in' ? '+' : '-') + formatNumber(t.amount, 2) + '</div></div>';
  }).join('');
}